"""
Generate Shreeja_Team_5_Members_Pitch_Script.docx
Personalized master script for Shreeja (Team Lead) and her 4 teammates.
"""

import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls


def set_cell_background(cell, fill_hex):
    tcPr = cell._element.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)


def generate_shreeja_doc():
    doc = docx.Document()

    for s in doc.sections:
        s.top_margin = Inches(0.8)
        s.bottom_margin = Inches(0.8)
        s.left_margin = Inches(0.8)
        s.right_margin = Inches(0.8)

    C_NAVY = RGBColor(11, 15, 25)
    C_CYAN = RGBColor(6, 182, 212)
    C_TEAL = RGBColor(20, 184, 166)
    C_GRAY = RGBColor(100, 116, 139)

    # Title
    p_badge = doc.add_paragraph()
    r_b = p_badge.add_run("TEAM SHREEJA • 5-MEMBER OFFICIAL HACKATHON PITCH SCRIPT (5-10 MIN)")
    r_b.font.bold = True
    r_b.font.size = Pt(9.5)
    r_b.font.color.rgb = C_CYAN

    p_title = doc.add_paragraph()
    r_t = p_title.add_run("ScamSathi AI — 5-Member Team Master Script")
    r_t.font.bold = True
    r_t.font.size = Pt(22)
    r_t.font.color.rgb = C_NAVY

    p_sub = doc.add_paragraph()
    r_s = p_sub.add_run("Turn-by-turn spoken script, screen actions, and transition handoffs for Shreeja (Lead) and team.")
    r_s.font.size = Pt(11)
    r_s.font.italic = True
    r_s.font.color.rgb = C_GRAY

    doc.add_paragraph().paragraph_format.space_after = Pt(10)

    # Table of Roles
    table = doc.add_table(rows=1, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = table.rows[0].cells
    for i, h in enumerate(["Member", "Name & Role", "Time", "Live Screen Action & Focus"]):
        hdr[i].text = h
        set_cell_background(hdr[i], "0B0F19")
        p = hdr[i].paragraphs[0]
        p.runs[0].font.bold = True
        p.runs[0].font.color.rgb = RGBColor(255, 255, 255)
        p.runs[0].font.size = Pt(9.5)

    data = [
        ("Member 1", "Shreeja (Team Lead)", "0:00 – 1:15", "Show Dashboard (http://127.0.0.1:5000), frame national ₹7,000 Cr crisis."),
        ("Member 2", "Phishing Message Lead", "1:15 – 2:30", "Demo Suspicious A vs Bank Advisory (False-Positive resistance)."),
        ("Member 3", "URL Analyzer Lead", "2:30 – 3:45", "Demo offline analysis of sbi-account-verify.invalid, bust HTTPS myth."),
        ("Member 4", "Camera Sandbox Lead", "3:45 – 5:00", "Demo courier scam, pure HTML/CSS prompt, deepfake defense."),
        ("Member 5", "Full-Stack & MongoDB Lead", "5:00 – 6:15", "Demo Community Threat Radar, MongoDB dual-mode, 34/34 tests passing."),
        ("Member 1", "Shreeja (Closing)", "6:15 – 6:45", "Final punchline, social impact, invite judges for Q&A."),
    ]

    for m, r, t, f in data:
        row = table.add_row().cells
        row[0].text = m
        row[1].text = r
        row[2].text = t
        row[3].text = f
        set_cell_background(row[0], "F1F5F9")
        for idx in range(4):
            p = row[idx].paragraphs[0]
            if p.runs:
                p.runs[0].font.size = Pt(9)

    doc.add_paragraph().paragraph_format.space_after = Pt(14)

    # Detailed Scripts
    sections = [
        {
            "header": "👑 MEMBER 1: SHREEJA (TEAM LEAD) — HOOK & PROBLEM STATEMENT",
            "time": "0:00 – 1:15 (75 Seconds)",
            "action": "Open ScamSathi AI Dashboard (http://127.0.0.1:5000). Stand tall, smile, make eye contact with all judges.",
            "script": (
                "\"Good morning, respected judges. I am Shreeja, and these are my teammates: [Name 2], [Name 3], [Name 4], and [Name 5]. "
                "Together, we have built ScamSathi AI: Detect the Scam. Expose the Trap. Protect Your Privacy.\n\n"
                "Judges, in India today, over ₹7,000 Crores was stolen from everyday citizens in a single year through digital financial fraud. "
                "Every single day, millions of people—especially our parents, senior citizens, and students—receive terrifying messages on WhatsApp and SMS: "
                "'Your electricity will be cut tonight at 9:30 PM', or 'Your bank account is blocked, click here to verify.'\n\n"
                "Attackers weaponize manufactured panic so victims click before thinking. When citizens look for help, existing tools fail them: "
                "traditional scanners are opaque black-boxes that say 'safe' or 'unsafe' without explaining why, or they force users to upload their private chats to corporate cloud servers.\n\n"
                "We built ScamSathi AI—an explainable, 100% privacy-first cybersecurity platform that detects scams in milliseconds, "
                "inspects dangerous links safely offline, and inoculates citizens against emerging camera-permission traps.\n\n"
                "To demonstrate our first defense module, I will now pass to [Name 2] to analyze live phishing messages.\""
            ),
            "handoff": "Shreeja gestures smoothly to Member 2. Keep the live laptop screen centered."
        },
        {
            "header": "✉️ MEMBER 2: PHISHING MESSAGE DETECTION SPECIALIST",
            "time": "1:15 – 2:30 (75 Seconds)",
            "action": "Click 'Message Detector' in nav. Select 'Suspicious A', click Analyze. Then select 'Legitimate Security: Official Bank Advisory', click Analyze.",
            "script": (
                "\"Thank you, Shreeja. Judges, when an ordinary citizen receives an alarming alert, they need explainable clarity, not a black-box guess.\n\n"
                "As you see on screen, I am loading a high-pressure scam: 'URGENT! Your bank account will be blocked today. Verify immediately and send your OTP.'\n\n"
                "In under 5 milliseconds, ScamSathi's contextual heuristic engine deconstructs the message. It highlights the urgency words in safe red boxes, "
                "explains the psychological trick, and calculates a High Risk score of 90 out of 100 with a clear warning: DO NOT PAY.\n\n"
                "But here is what makes ScamSathi truly intelligent: False-Positive Resistance. Naive AI tools flag any message containing the words 'bank' or 'OTP' as a scam. "
                "Watch what happens when I load an official bank advisory: 'Your bank will never ask you to share your OTP or PIN.'\n\n"
                "Our contextual negation engine recognizes this as an official anti-scam notice. It suppresses the penalty and scores it in the safe LOW RISK green band. "
                "Zero false alarms.\n\n"
                "Now, how do we inspect the malicious web links inside these messages without risking malware? Over to [Name 3] for our URL Analyzer.\""
            ),
            "handoff": "Point to the URL Analyzer navigation link and pass to Member 3."
        },
        {
            "header": "🔗 MEMBER 3: SUSPICIOUS URL ANALYSIS SPECIALIST",
            "time": "2:30 – 3:45 (75 Seconds)",
            "action": "Click 'URL Analyzer' in nav. Select 'Brand Spoofing: http://sbi-account-verify.invalid/update-kyc', click Analyze. Point out the anatomy breakdown and 'Why HTTPS != Safe' card.",
            "script": (
                "\"Thank you, [Name 2]. Opening an unknown link is like stepping onto an uninspected minefield. Traditional online scanners make the dangerous mistake "
                "of pinging or crawling the link—which alerts the hacker, exposes the victim's IP address, and risks drive-by malware downloads.\n\n"
                "ScamSathi AI operates on a 100% Zero-Network Guarantee. We analyze links purely through offline string decomposition and IP verification using Python standard libraries. "
                "We never send a single network packet to the remote server.\n\n"
                "As you see on screen, we analyzed 'http://sbi-account-verify.invalid'. ScamSathi instantly identifies that an unauthorized domain is impersonating the State Bank of India brand. "
                "We flag raw IP addresses, hidden URL shorteners, and deceptive user-info '@' syntax.\n\n"
                "Most importantly, we bust the #1 myth among internet users: that an HTTPS padlock means a website is honest. "
                "Our educational callout explains that phishers use free SSL certificates too; an encrypted connection does not mean the website owner is benevolent.\n\n"
                "Now, to show how we tackle emerging hardware permission scams, I pass to [Name 4].\""
            ),
            "handoff": "Navigate to the Camera Simulator tab and hand over to Member 4."
        },
        {
            "header": "📷 MEMBER 4: CAMERA-PHISHING AWARENESS SANDBOX SPECIALIST",
            "time": "3:45 – 5:00 (75 Seconds)",
            "action": "On Camera Simulator page (/simulator), click 'Simulate Clicking the Link'. Show mock prompt, click 'Simulate Deny' (then 'Simulate Allow'). Show the 6-point checklist.",
            "script": (
                "\"Thank you, [Name 3]. Cybercriminals are constantly inventing new deception vectors. An emerging threat in India is Camera-Permission Phishing. "
                "Attackers send fake parcel delivery alerts claiming: 'Delivery incomplete! Open link to scan your face.' When opened, the page pressures users for camera permission. "
                "Once granted, hackers record facial video to bypass selfie-KYC on banking apps, train AI deepfakes, or extort victims.\n\n"
                "ScamSathi AI features India's first Camera-Phishing Awareness Sandbox. Notice our prominent safety notice: this is strictly educational—our codebase contains "
                "ZERO real camera APIs or getUserMedia calls.\n\n"
                "As you see on screen, the user experiences a realistic mock delivery portal with an HTML/CSS simulated browser prompt. "
                "If the user simulates 'Allow', we reveal how facial biometrics are stolen. If they simulate 'Deny', it reinforces the golden security rule: "
                "a package courier never needs your webcam to deliver a physical box!\n\n"
                "It concludes with an actionable 6-point checklist teaching users how to audit and revoke old permissions in their browser settings.\n\n"
                "To discuss our full-stack engineering, MongoDB telemetry, and social impact, here is [Name 5].\""
            ),
            "handoff": "Step to the side and gesture to Member 5 for the technical and concluding pitch."
        },
        {
            "header": "🍃 MEMBER 5: FULL-STACK ENGINEERING & MONGODB TELEMETRY LEAD",
            "time": "5:00 – 6:15 (75 Seconds)",
            "action": "Navigate to Dashboard and scroll down to the Live Community Threat Radar. Point to the 'MongoDB / In-Memory' status pill and the live feed table.",
            "script": (
                "\"Thank you, [Name 4]. Behind ScamSathi AI is a robust, production-grade architecture built with Python Flask and MongoDB.\n\n"
                "On our dashboard, you can see our live Community Threat Intelligence Radar. Every time a high-risk scam or spoofed domain is flagged, "
                "sanitized threat telemetry is recorded via our '/api/threat-intel' REST API. In strict compliance with India's DPDP Act, "
                "we never store user messages, phone numbers, or private data—only anonymized threat indicators.\n\n"
                "Furthermore, our database layer features a dual-mode zero-crash fallback: when MongoDB is connected, it persists live threat signals; "
                "if MongoDB is offline, it automatically falls back to an in-memory buffer, guaranteeing the app never throws connection errors on any evaluation system.\n\n"
                "Our codebase is complete with 34 out of 34 automated unit and integration tests passing in under 8 seconds. "
                "We enforce Content Security Policy, anti-CSRF tokens, frame denial, and safe HTML escaping. "
                "Every page directly integrates India's official 1930 Cyber Crime Helpline and cybercrime.gov.in.\""
            ),
            "handoff": "Member 5 gestures back to Shreeja for the grand conclusion."
        },
        {
            "header": "🏆 SHREEJA (TEAM LEAD) — FINAL CONCLUSION & Q&A HOOK",
            "time": "6:15 – 6:45 (30 Seconds)",
            "action": "Shreeja steps to the center, standing shoulder-to-shoulder with all 4 teammates, smiling confidently at the judges.",
            "script": (
                "\"To conclude, judges: ScamSathi AI is not a theoretical slide deck. It is a live, fully functional, and tested cyber defense platform "
                "built to protect 800 million Indian smartphone users.\n\n"
                "By replacing opaque black-box verdicts with explainable heuristics, 100% offline URL safety, and hands-on simulation, "
                "we turn everyday citizens from helpless victims into informed digital defenders.\n\n"
                "ScamSathi AI: Detect the Scam. Expose the Trap. Protect Your Privacy.\n\n"
                "Thank you, and our team is ready to answer your questions!\""
            ),
            "handoff": "All 5 members stand together, ready for Q&A. Shreeja directs questions to the right specialist."
        }
    ]

    for sec in sections:
        p_h = doc.add_paragraph()
        p_h.paragraph_format.space_before = Pt(14)
        p_h.paragraph_format.space_after = Pt(2)
        r_h = p_h.add_run(sec["header"])
        r_h.font.bold = True
        r_h.font.size = Pt(12)
        r_h.font.color.rgb = C_CYAN

        t = doc.add_table(rows=2, cols=2)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.rows[0].cells[0].text = "⏱️ Time Allocation:"
        t.rows[0].cells[1].text = sec["time"]
        t.rows[1].cells[0].text = "💻 Live Screen Action:"
        t.rows[1].cells[1].text = sec["action"]

        for row in t.rows:
            set_cell_background(row.cells[0], "F8FAFC")
            set_cell_background(row.cells[1], "F1F5F9")
            for c in row.cells:
                p = c.paragraphs[0]
                p.runs[0].font.size = Pt(9)
                p.runs[0].font.color.rgb = C_NAVY

        p_sh = doc.add_paragraph()
        p_sh.paragraph_format.space_before = Pt(6)
        r_sh = p_sh.add_run("🎙️ Spoken Script (Say this clearly and confidently):")
        r_sh.font.bold = True
        r_sh.font.size = Pt(9.5)
        r_sh.font.color.rgb = C_TEAL

        p_scr = doc.add_paragraph()
        p_scr.paragraph_format.left_indent = Inches(0.2)
        r_sc = p_scr.add_run(sec["script"])
        r_sc.font.size = Pt(10)
        r_sc.font.color.rgb = C_NAVY

        p_tr = doc.add_paragraph()
        r_tr = p_tr.add_run("🤝 Transition Tip: " + sec["handoff"])
        r_tr.font.italic = True
        r_tr.font.size = Pt(8.5)
        r_tr.font.color.rgb = C_GRAY

    # Traffic Controller Q&A Rules
    doc.add_page_break()
    p_q = doc.add_paragraph()
    r_q = p_q.add_run("🎯 Shreeja's 'Traffic Controller' Strategy for Q&A")
    r_q.font.bold = True
    r_q.font.size = Pt(16)
    r_q.font.color.rgb = C_CYAN

    qa_rules = [
        ("When a judge asks about Risk Scoring or False Positives:", "Shreeja says: 'Great question! Our message detection specialist, [Name 2], can explain our contextual negation engine.'"),
        ("When a judge asks about URLs, Offline Inspection, or Network Calls:", "Shreeja says: 'Our URL specialist, [Name 3], can walk you through our zero-network string decomposition.'"),
        ("When a judge asks about Camera Safety, Permissions, or Deepfakes:", "Shreeja says: '[Name 4] can explain how our pure DOM sandbox works without webcam hardware.'"),
        ("When a judge asks about MongoDB, Performance, or Scalability:", "Shreeja says: '[Name 5] can explain our dual-mode MongoDB architecture and zero-crash fallback.'"),
        ("When a judge asks about Business, Vision, or Next Steps:", "Shreeja answers directly: 'Our priority is on-device Indic language NLP for regional India and releasing a Chrome extension.'"),
    ]

    for title, script in qa_rules:
        p_r = doc.add_paragraph()
        r_1 = p_r.add_run(f"• {title}\n  ")
        r_1.font.bold = True
        r_1.font.color.rgb = C_NAVY
        r_2 = p_r.add_run(f"{script}")
        r_2.font.italic = True
        r_2.font.color.rgb = C_TEAL

    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "Shreeja_Team_5_Members_Pitch_Script.docx")
    doc.save(out)
    print(f"Personalized script saved successfully to: {out}")


if __name__ == "__main__":
    generate_shreeja_doc()
