"""
Generate a professional, high-impact PowerPoint pitch deck (.pptx)
for ScamSathi AI hackathon presentation.
"""

import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

def create_presentation():
    prs = Presentation()
    # 16:9 widescreen dimensions
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # Theme colors
    C_BG = RGBColor(11, 15, 25)          # Deep Navy Near-Black #0B0F19
    C_CARD = RGBColor(21, 30, 50)        # Card Navy #151E32
    C_CARD_BORDER = RGBColor(6, 182, 212) # Cyan #06B6D4
    C_CYAN = RGBColor(6, 182, 212)       # Brand Cyan #06B6D4
    C_TEAL = RGBColor(20, 184, 166)      # Accent Teal #14B8A6
    C_WHITE = RGBColor(248, 250, 252)    # Title White #F8FAFC
    C_SLATE = RGBColor(148, 163, 184)    # Body Slate #94A3B8
    C_AMBER = RGBColor(245, 158, 11)     # Warning Amber #F59E0B
    C_RED = RGBColor(239, 68, 68)        # Danger Red #EF4444
    C_GREEN = RGBColor(16, 185, 129)     # Safe Green #10B981

    blank_layout = prs.slide_layouts[6]

    def set_slide_background(slide):
        bg_shape = slide.shapes.add_shape(
            MSO_SHAPE.RECTANGLE, Inches(0), Inches(0), prs.slide_width, prs.slide_height
        )
        bg_shape.fill.solid()
        bg_shape.fill.fore_color.rgb = C_BG
        bg_shape.line.fill.background()
        return bg_shape

    def add_header(slide, tag_text, title_text):
        # Category Tag
        tag_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.5), Inches(11.7), Inches(0.4))
        tf_tag = tag_box.text_frame
        tf_tag.word_wrap = True
        p_tag = tf_tag.paragraphs[0]
        p_tag.text = tag_text.upper()
        p_tag.font.name = "Arial"
        p_tag.font.size = Pt(11)
        p_tag.font.bold = True
        p_tag.font.color.rgb = C_CYAN

        # Title
        title_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.85), Inches(11.7), Inches(0.8))
        tf_title = title_box.text_frame
        tf_title.word_wrap = True
        p_title = tf_title.paragraphs[0]
        p_title.text = title_text
        p_title.font.name = "Arial"
        p_title.font.size = Pt(26)
        p_title.font.bold = True
        p_title.font.color.rgb = C_WHITE

    def add_card(slide, left, top, width, height, title, body_lines, accent_color=C_CYAN, icon=""):
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        card.fill.solid()
        card.fill.fore_color.rgb = C_CARD
        card.line.color.rgb = accent_color
        card.line.width = Pt(1.5)

        tf = card.text_frame
        tf.word_wrap = True
        tf.margin_left = Inches(0.25)
        tf.margin_right = Inches(0.25)
        tf.margin_top = Inches(0.25)
        tf.margin_bottom = Inches(0.25)

        p_first = tf.paragraphs[0]
        header_text = f"{icon}  {title}" if icon else title
        p_first.text = header_text
        p_first.font.name = "Arial"
        p_first.font.size = Pt(16)
        p_first.font.bold = True
        p_first.font.color.rgb = accent_color
        p_first.space_after = Pt(10)

        for line in body_lines:
            p = tf.add_paragraph()
            p.text = line
            p.font.name = "Arial"
            p.font.size = Pt(12)
            p.font.color.rgb = C_SLATE
            p.space_after = Pt(6)

        return card

    # =========================================================================
    # SLIDE 1: Title Slide (Cover)
    # =========================================================================
    s1 = prs.slides.add_slide(blank_layout)
    set_slide_background(s1)

    # Accent decorative banner
    bar = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.5), Inches(0.15), Inches(3.8))
    bar.fill.solid()
    bar.fill.fore_color.rgb = C_CYAN
    bar.line.fill.background()

    # Title box
    tbox = s1.shapes.add_textbox(Inches(1.2), Inches(1.5), Inches(11.0), Inches(3.8))
    tf = tbox.text_frame
    tf.word_wrap = True

    p0 = tf.paragraphs[0]
    p0.text = "NATIONAL CYBER DEFENSE HACKATHON 2026"
    p0.font.name = "Arial"
    p0.font.size = Pt(13)
    p0.font.bold = True
    p0.font.color.rgb = C_CYAN
    p0.space_after = Pt(12)

    p1 = tf.add_paragraph()
    p1.text = "ScamSathi AI (स्कैम साथी)"
    p1.font.name = "Arial"
    p1.font.size = Pt(44)
    p1.font.bold = True
    p1.font.color.rgb = C_WHITE
    p1.space_after = Pt(8)

    p2 = tf.add_paragraph()
    p2.text = "Detect the Scam. Expose the Trap. Protect Your Privacy."
    p2.font.name = "Arial"
    p2.font.size = Pt(22)
    p2.font.bold = True
    p2.font.color.rgb = C_TEAL
    p2.space_after = Pt(16)

    p3 = tf.add_paragraph()
    p3.text = "An explainable, 100% privacy-first cybersecurity awareness platform empowering citizens against phishing messages, malicious URLs, and camera-permission traps."
    p3.font.name = "Arial"
    p3.font.size = Pt(14)
    p3.font.color.rgb = C_SLATE

    # Badges at bottom
    add_card(s1, Inches(1.2), Inches(5.6), Inches(3.5), Inches(1.2), "100% Offline Engine", ["Zero tracking, zero cloud leaks", "Runs purely in local RAM"], C_CYAN, "🔒")
    add_card(s1, Inches(5.0), Inches(5.6), Inches(3.5), Inches(1.2), "Explainable Scoring", ["Transparent 0-100 heuristic breakdown", "Highlights exact coercion triggers"], C_TEAL, "⚡")
    add_card(s1, Inches(8.8), Inches(5.6), Inches(3.5), Inches(1.2), "Camera Phishing Sandbox", ["Pure DOM training simulation", "Zero real webcam hardware access"], C_AMBER, "📷")

    s1.notes_slide.notes_text_frame.text = (
        "Opening (0:00-0:30): Good morning judges! Today we present ScamSathi AI. "
        "Over ₹7,000 Crores was lost to digital scams in India. We built ScamSathi AI to detect scams, "
        "expose deceptive URLs safely offline, and educate citizens without compromising their privacy."
    )

    # =========================================================================
    # SLIDE 2: Problem Statement (The Crisis in India)
    # =========================================================================
    s2 = prs.slides.add_slide(blank_layout)
    set_slide_background(s2)
    add_header(s2, "The Cybersecurity Crisis", "India's ₹7,000+ Crore Digital Fraud Epidemic")

    add_card(s2, Inches(0.8), Inches(1.8), Inches(3.6), Inches(4.8), "Manufactured Panic", [
        "🚨 Attack Vector:",
        "Scammers send urgent WhatsApp/SMS alerts threatening bank account blocking, SIM deactivation, or power disconnection in 2 hours.",
        "",
        "🎯 Human Impact:",
        "Panic disables critical thinking, coercing victims into clicking links and sharing OTPs before verifying authenticity."
    ], C_RED, "⏳")

    add_card(s2, Inches(4.8), Inches(1.8), Inches(3.6), Inches(4.8), "Silent Permission Traps", [
        "📸 Emerging Exploit:",
        "Deceptive parcel tracking and fake job portals pressure users into granting browser camera permissions.",
        "",
        "🤖 Synthetic Identity Theft:",
        "Captured biometric facial frames and surroundings are weaponized for deepfakes, extortion, and KYC spoofing."
    ], C_AMBER, "👁️")

    add_card(s2, Inches(8.8), Inches(1.8), Inches(3.6), Inches(4.8), "Flawed Current Tools", [
        "❌ Opaque Black Boxes:",
        "Tools say 'safe' or 'unsafe' with zero explanation—citizens never learn to recognize deception.",
        "",
        "❌ Privacy Nightmares:",
        "Commercial scanners require users to upload confidential private chats to foreign cloud servers."
    ], C_CYAN, "🛡️")

    s2.notes_slide.notes_text_frame.text = (
        "Slide 2: Highlight the scale. Citizens are hit by manufactured panic (electricity cuts, fake courier delivery). "
        "Worse, emerging attacks now trick users into granting camera permissions. Existing tools either spy on users or give opaque black-box verdicts."
    )

    # =========================================================================
    # SLIDE 3: The ScamSathi AI Solution
    # =========================================================================
    s3 = prs.slides.add_slide(blank_layout)
    set_slide_background(s3)
    add_header(s3, "Our Solution", "Three Pillars of Complete Citizen Cyber Defense")

    add_card(s3, Inches(0.8), Inches(1.8), Inches(3.6), Inches(4.8), "1. Phishing Message Detector", [
        "✉️ Contextual Heuristics:",
        "Scans SMS, WhatsApp, and emails for urgency, advance-fee traps, and credential theft.",
        "",
        "🧠 Smart Context Awareness:",
        "Avoids false positives: identifies bank advisories ('bank will never ask you for OTP') as Low Risk.",
        "",
        "📊 Transparent 0–100 Score:",
        "Maps into Low (0-29), Medium (30-59), and High (60-100) risk bands with highlighted evidence."
    ], C_CYAN, "✉️")

    add_card(s3, Inches(4.8), Inches(1.8), Inches(3.6), Inches(4.8), "2. Suspicious URL Analyzer", [
        "🔗 100% Offline Inspection:",
        "Evaluates syntax and hosts without sending a single network packet to the destination.",
        "",
        "🎯 Deception Signatures:",
        "Flags raw IP addresses, brand typosquatting (sbi-verify.invalid), shorteners, and '@' user-info tricks.",
        "",
        "💡 HTTPS Reality Check:",
        "Teaches users that an HTTPS padlock guarantees transport encryption, NOT website honesty."
    ], C_TEAL, "🔗")

    add_card(s3, Inches(8.8), Inches(1.8), Inches(3.6), Inches(4.8), "3. Camera-Phishing Sandbox", [
        "📷 Safe Interactive Education:",
        "Realistic 4-stage simulation of parcel-delivery permission phishing.",
        "",
        "🛡️ Pure HTML/CSS Simulation:",
        "Zero getUserMedia calls, zero hardware activation, zero biometric data collected.",
        "",
        "📋 Actionable Defense:",
        "Walks users through browser permission revocation and official reporting to 1930."
    ], C_AMBER, "📷")

    s3.notes_slide.notes_text_frame.text = (
        "Slide 3: Explain the 3 modules. We don't just detect phishing messages; we analyze URLs safely offline, "
        "and we provide India's first interactive simulator for camera-permission phishing."
    )

    # =========================================================================
    # SLIDE 4: Module 1 Deep Dive — Phishing Message Detector
    # =========================================================================
    s4 = prs.slides.add_slide(blank_layout)
    set_slide_background(s4)
    add_header(s4, "Module 1 Breakdown", "AI Phishing Message Detector: Explainable & Context-Aware")

    add_card(s4, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), "Heuristic Detection Matrix", [
        "⚡ Urgency Triggers (+15 pts):",
        "  'Immediately', 'Account blocked today', 'Action required'.",
        "",
        "🛑 Threat & Suspension (+25 pts):",
        "  'Card blocked', 'Services stopped', 'Electricity cutoff'.",
        "",
        "🎁 Prize & Advance Fee (+25 to +30 pts):",
        "  'Won ₹50,000 reward', 'Pay ₹999 processing charge'.",
        "",
        "🔑 Credential Theft (+35 pts):",
        "  'Send your OTP', 'Enter MPIN', 'Card CVV'.",
        "",
        "🔥 Synergistic Combo Multiplier (+15 to +20 pts):",
        "  Detects deadly combos like [Urgent Threat + External Verification Link]."
    ], C_CYAN, "⚙️")

    add_card(s4, Inches(6.8), Inches(1.8), Inches(5.6), Inches(4.8), "False-Positive Resistance & Safety", [
        "🛡️ Contextual Negation Filtering:",
        "• If a message states: 'Your bank will never ask you to share your OTP or PIN...'",
        "• Naive keyword scanners flag this as a phishing attack.",
        "• ScamSathi recognizes the anti-scam advisory context and assigns LOW RISK (0-15 pts).",
        "",
        "🔒 XSS Defense in Evidence Display:",
        "• Suspicious terms are highlighted in safe HTML.",
        "• All user inputs are strictly escaped with html.escape() to prevent cross-site scripting exploits.",
        "",
        "📋 Tailored Action Recommendations:",
        "• Directs victims to official card helpline numbers and national 1930 reporting."
    ], C_GREEN, "✅")

    s4.notes_slide.notes_text_frame.text = (
        "Slide 4: Walk through the scoring logic. Emphasize false positive protection: when a bank sends legitimate security advice, "
        "our system recognizes it as an advisory rather than penalizing words like 'OTP' and 'bank'."
    )

    # =========================================================================
    # SLIDE 5: Module 2 Deep Dive — Suspicious URL Analyzer
    # =========================================================================
    s5 = prs.slides.add_slide(blank_layout)
    set_slide_background(s5)
    add_header(s5, "Module 2 Breakdown", "Suspicious URL Analyzer: 100% Offline Structural Inspection")

    add_card(s5, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), "Zero-Network Safety Architecture", [
        "🚫 The Dangerous Mistake in Ordinary Scanners:",
        "• Traditional scanners ping or crawl submitted URLs.",
        "• This alerts attackers, exposes victim IP addresses, and risks browser drive-by downloads.",
        "",
        "🛡️ ScamSathi's Zero-Network Guarantee:",
        "• ZERO HTTP requests, ZERO DNS queries, ZERO downloads.",
        "• 100% string-based inspection using urllib.parse and ipaddress.",
        "• Verified in pytest by asserting zero socket.connect() calls."
    ], C_CYAN, "🔒")

    add_card(s5, Inches(6.8), Inches(1.8), Inches(5.6), Inches(4.8), "Threat Signatures Detected", [
        "🌐 Raw IP Hostnames (+40 pts):",
        "  http://185.220.101.5/login (bypasses domain registration filters).",
        "",
        "🏦 Brand Spoofing & Typosquatting (+35 pts):",
        "  http://sbi-account-verify.invalid or paytrm.xyz.",
        "",
        "🎭 Deceptive User-Info Syntax (+40 pts):",
        "  http://google.com@attacker-portal.invalid (browser connects to attacker!).",
        "",
        "🔗 URL Shorteners & Subdomain Stacking (+20-25 pts):",
        "  bit.ly links, or chains that push real domains off smartphone screens.",
        "",
        "💡 HTTPS Education:",
        "  Busts the myth: free SSL certificates do NOT guarantee honesty."
    ], C_TEAL, "🔍")

    s5.notes_slide.notes_text_frame.text = (
        "Slide 5: Highlight our offline approach. Opening unknown links is dangerous. ScamSathi AI performs 100% offline analysis. "
        "We catch brand spoofing, raw IP hosts, and deceptive @ symbols without ever touching the attacker's server."
    )

    # =========================================================================
    # SLIDE 6: Module 3 Deep Dive — Camera Phishing Simulator
    # =========================================================================
    s6 = prs.slides.add_slide(blank_layout)
    set_slide_background(s6)
    add_header(s6, "Module 3 Breakdown", "Camera Phishing Awareness Simulator: Safe Interactive Inoculation")

    add_card(s6, Inches(0.8), Inches(1.8), Inches(3.6), Inches(4.8), "Stage 1 & 2: The Trap", [
        "📦 Stage 1 — The Urgent Lure:",
        "User sees a realistic fictional delivery SMS: 'Parcel #IN-8092 blocked, open verification link'.",
        "",
        "💻 Stage 2 — Mock Courier Portal:",
        "Renders a simulated delivery site with a mock HTML/CSS browser permission pop-up:",
        "'track-express.invalid wants to use your camera'.",
        "",
        "🕹️ Interactive Simulation:",
        "User chooses 'Simulate Allow' or 'Simulate Deny'."
    ], C_AMBER, "🎭")

    add_card(s6, Inches(4.8), Inches(1.8), Inches(3.6), Inches(4.8), "Stage 3: Educational Payoff", [
        "🚨 If User Simulates 'Allow':",
        "Reveals the hidden dangers of granting camera access to untrusted sites:",
        "• Facial biometric theft for KYC spoofing",
        "• AI deepfake video creation to scam relatives",
        "• Ambient reconnaissance & extortion",
        "",
        "🛡️ If User Simulates 'Deny':",
        "Praises the correct reflex: couriers NEVER legitimately need your webcam to deliver a box!"
    ], C_RED, "💡")

    add_card(s6, Inches(8.8), Inches(1.8), Inches(3.6), Inches(4.8), "Stage 4: Defense & Audit", [
        "📋 Actionable Defense Rules:",
        "1. Verify address bar domain before acting.",
        "2. Default to DENY for hardware requests.",
        "3. Review and revoke old browser permissions (chrome://settings/content).",
        "4. Report fraud immediately to 1930.",
        "",
        "🔒 Zero-API Safety Proof:",
        "Tested to confirm zero getUserMedia or hardware camera APIs exist in the codebase."
    ], C_GREEN, "📋")

    s6.notes_slide.notes_text_frame.text = (
        "Slide 6: Show off the simulator. Camera phishing is an emerging threat. "
        "Our pure HTML/CSS simulator lets users experience the deception safely with zero hardware risk, "
        "inoculating them against real-world social engineering."
    )

    # =========================================================================
    # SLIDE 7: Technical Architecture & Security
    # =========================================================================
    s7 = prs.slides.add_slide(blank_layout)
    set_slide_background(s7)
    add_header(s7, "Engineering & Architecture", "Privacy-First, Local-First, Hardened Architecture")

    add_card(s7, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), "Lightweight & Robust Tech Stack", [
        "🐍 Python 3.10+ & Flask 3.1 Backend:",
        "• Modular architecture with separate detector engines.",
        "• Sub-5ms execution time per analysis request.",
        "• High concurrency without requiring expensive GPUs.",
        "",
        "🍃 Dual-Mode MongoDB Threat Intelligence Backend:",
        "• Stores anonymous scam patterns & trends via pymongo (/api/threat-intel).",
        "• Zero-crash fallback: uses in-memory buffer if MongoDB is offline.",
        "• Zero personal data stored (never saves user SMS or phone numbers).",
        "",
        "🧪 33 Automated Tests (100% Pass Rate):",
        "• pytest suite covering heuristics, MongoDB fallback, XSS, and security."
    ], C_CYAN, "💻")

    add_card(s7, Inches(6.8), Inches(1.8), Inches(5.6), Inches(4.8), "Enterprise-Grade Security Standards", [
        "🔒 Zero-Trust Privacy Engineering:",
        "• No user chats saved. Analysis occurs only in transient RAM.",
        "• Anonymized threat telemetry (domain, brand, indicator categories).",
        "",
        "🛡️ Defense-in-Depth HTTP Headers:",
        "• Content-Security-Policy: default-src 'self'",
        "• X-Frame-Options: DENY (prevents clickjacking)",
        "• X-Content-Type-Options: nosniff",
        "",
        "🔑 Anti-CSRF Token Enforcement:",
        "• Cryptographically validated tokens on all POST requests.",
        "",
        "🌐 Zero Cloud Leakage:",
        "• Never sends your personal messages to third-party APIs."
    ], C_TEAL, "🛡️")

    s7.notes_slide.notes_text_frame.text = (
        "Slide 7: Technical credibility. Built with Python Flask and MongoDB for anonymous threat intelligence, "
        "sub-5ms latency, CSRF protection, Content Security Policy, and 33 passing automated tests with zero-crash fallback."
    )

    # =========================================================================
    # SLIDE 8: Competitive Comparison
    # =========================================================================
    s8 = prs.slides.add_slide(blank_layout)
    set_slide_background(s8)
    add_header(s8, "Competitive Advantage", "Why ScamSathi AI Wins Over Alternatives")

    add_card(s8, Inches(0.8), Inches(1.8), Inches(2.7), Inches(4.8), "VirusTotal / Scanners", [
        "❌ Pings remote links (risks drive-by malware)",
        "❌ Exposes user IP address to attacker",
        "❌ Opaque binary verdict (Clean/Malicious)",
        "❌ Zero Indian scam context",
        "❌ No message text analysis",
        "❌ No permission training simulator"
    ], C_SLATE, "🌐")

    add_card(s8, Inches(3.7), Inches(1.8), Inches(2.7), Inches(4.8), "Truecaller / SMS Apps", [
        "❌ Uploads user address books to servers",
        "❌ Relies heavily on crowdsourced spam flags",
        "❌ Cannot explain why a link is dangerous",
        "❌ No deep URL syntactic decomposition",
        "❌ Misses newly created 0-day scam domains",
        "❌ No camera-phishing education"
    ], C_SLATE, "📱")

    add_card(s8, Inches(6.6), Inches(1.8), Inches(2.7), Inches(4.8), "Generic Cloud LLMs", [
        "❌ Sends confidential chats to foreign cloud APIs",
        "❌ Hallucinates and provides inconsistent scores",
        "❌ High latency (>1-3 seconds) and API cost",
        "❌ Inconsistent scoring thresholds",
        "❌ No offline execution capability",
        "❌ No structured browser simulator"
    ], C_SLATE, "🤖")

    add_card(s8, Inches(9.5), Inches(1.8), Inches(3.0), Inches(4.8), "ScamSathi AI (Ours)", [
        "✅ 100% Offline & Local (Zero data leakage)",
        "✅ Instant execution (<5ms, zero API cost)",
        "✅ Explainable scoring with highlighted evidence",
        "✅ Context-aware false positive protection",
        "✅ India-specific scam patterns (KYC, electricity, delivery)",
        "✅ First interactive Camera Phishing Sandbox"
    ], C_GREEN, "🏆")

    s8.notes_slide.notes_text_frame.text = (
        "Slide 8: Comparison table. Unlike VirusTotal, we don't ping dangerous links. "
        "Unlike Truecaller, we don't harvest contact books. Unlike cloud LLMs, we don't leak private data and we execute in 5 milliseconds."
    )

    # =========================================================================
    # SLIDE 9: Social Impact & Scalability Roadmap
    # =========================================================================
    s9 = prs.slides.add_slide(blank_layout)
    set_slide_background(s9)
    add_header(s9, "Impact & Roadmap", "Democratizing Cyber Safety for 800+ Million Indians")

    add_card(s9, Inches(0.8), Inches(1.8), Inches(5.6), Inches(4.8), "Immediate Social Impact", [
        "👴 Senior Citizens & First-Time Digital Users:",
        "  Clear, simple explanations without complex technical jargon.",
        "",
        "🏪 Small Businesses & Gig Workers:",
        "  Guards against fake payment screenshots, job deposits, and delivery traps.",
        "",
        "🇮🇳 National Helpline Integration:",
        "  Every page directly links to India's National Cyber Crime Portal (1930 / cybercrime.gov.in).",
        "",
        "📚 Digital Literacy Inoculation:",
        "  Users don't just see a score; they learn the mental models of social engineering."
    ], C_CYAN, "🌍")

    add_card(s9, Inches(6.8), Inches(1.8), Inches(5.6), Inches(4.8), "Future Scalability Roadmap", [
        "🗣️ On-Device Regional NLP (IndicBERT):",
        "  Integrate lightweight local ONNX models for Hindi, Tamil, Telugu, and Bengali.",
        "",
        "📸 Local Screenshot OCR (Tesseract):",
        "  Allow senior citizens to snap a WhatsApp screenshot without typing.",
        "",
        "🧩 ScamSathi Shield Browser Extension:",
        "  Package the offline URL engine into Chrome/Firefox to warn users before clicking.",
        "",
        "📡 Telco & SMS Gateway Integration:",
        "  Lightweight rule engine can run on edge gateways to filter bulk scam SMS."
    ], C_TEAL, "🚀")

    s9.notes_slide.notes_text_frame.text = (
        "Slide 9: Explain our impact. ScamSathi AI democratizes cyber defense for India's 800 million smartphone users. "
        "Our roadmap includes regional Indic languages and a browser extension."
    )

    # =========================================================================
    # SLIDE 10: Conclusion & Live Pitch Call to Action
    # =========================================================================
    s10 = prs.slides.add_slide(blank_layout)
    set_slide_background(s10)

    # Accent decorative bar
    bar10 = s10.shapes.add_shape(MSO_SHAPE.RECTANGLE, Inches(0.8), Inches(1.5), Inches(0.15), Inches(3.8))
    bar10.fill.solid()
    bar10.fill.fore_color.rgb = C_CYAN
    bar10.line.fill.background()

    tbox10 = s10.shapes.add_textbox(Inches(1.2), Inches(1.5), Inches(11.0), Inches(3.8))
    tf10 = tbox10.text_frame
    tf10.word_wrap = True

    p0 = tf10.paragraphs[0]
    p0.text = "READY FOR PRODUCTION & IMMEDIATE DEPLOYMENT"
    p0.font.name = "Arial"
    p0.font.size = Pt(13)
    p0.font.bold = True
    p0.font.color.rgb = C_CYAN
    p0.space_after = Pt(10)

    p1 = tf10.add_paragraph()
    p1.text = "Detect the Scam. Expose the Trap. Protect Your Privacy."
    p1.font.name = "Arial"
    p1.font.size = Pt(36)
    p1.font.bold = True
    p1.font.color.rgb = C_WHITE
    p1.space_after = Pt(12)

    p2 = tf10.add_paragraph()
    p2.text = "ScamSathi AI bridges the digital safety divide with explainable heuristics, zero network risks, and hands-on simulation."
    p2.font.name = "Arial"
    p2.font.size = Pt(18)
    p2.font.color.rgb = C_SLATE
    p2.space_after = Pt(24)

    p3 = tf10.add_paragraph()
    p3.text = "🌐 Live Demo: http://127.0.0.1:5000  •  📁 Codebase: 100% Complete & Tested (33/33)  •  📞 Helpline: 1930"
    p3.font.name = "Arial"
    p3.font.size = Pt(14)
    p3.font.bold = True
    p3.font.color.rgb = C_TEAL

    add_card(s10, Inches(1.2), Inches(5.6), Inches(3.5), Inches(1.2), "Complete Codebase", ["All files written & committed", "Zero placeholders or mocks"], C_CYAN, "📁")
    add_card(s10, Inches(5.0), Inches(5.6), Inches(3.5), Inches(1.2), "33/33 Tests Passing", ["Automated pytest suite", "MongoDB fallback verified"], C_GREEN, "🧪")
    add_card(s10, Inches(8.8), Inches(5.6), Inches(3.5), Inches(1.2), "Demo Ready", ["Live on port 5000", "Timed 3-min pitch script ready"], C_AMBER, "🎯")

    s10.notes_slide.notes_text_frame.text = (
        "Conclusion (2:40-3:00): Thank you judges! ScamSathi AI is tested, fully functional, and ready right now. "
        "We are ready for live questions and demonstration!"
    )

    output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ScamSathi_AI_Pitch_Deck.pptx")
    prs.save(output_path)
    print(f"Presentation saved successfully to: {output_path}")

    # Also attempt updating primary file if not locked
    primary_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ScamSathi_AI_Hackathon_Pitch.pptx")
    try:
        prs.save(primary_path)
        print(f"Primary presentation also updated: {primary_path}")
    except PermissionError:
        print("Note: Primary PPTX is currently open in PowerPoint. Updated copy saved as ScamSathi_AI_Pitch_Deck.pptx")

if __name__ == "__main__":
    create_presentation()
