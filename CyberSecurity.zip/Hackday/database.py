"""
ScamSathi AI - Threat Intelligence & Community Radar Database
Dual-mode backend: Connects to MongoDB when available (local or Atlas URI),
with automatic, seamless in-memory fallback if MongoDB is offline.

STRICT PRIVACY GUARANTEE:
Never stores user phone numbers, raw message texts, or personal identifiers.
Only records sanitized threat indicators and detected scam domains.
"""

from collections import deque
from datetime import datetime, timezone
import os
import threading
from typing import Any, Dict, List, Optional

try:
    from pymongo import MongoClient, DESCENDING
    from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
    PYMONGO_AVAILABLE = True
except ImportError:
    PYMONGO_AVAILABLE = False


class ThreatIntelDB:
    """Anonymous Threat Intelligence Manager with MongoDB + In-Memory Fallback."""

    def __init__(self, mongo_uri: Optional[str] = None):
        self.mongo_uri = mongo_uri or os.environ.get(
            "MONGO_URI", "mongodb://localhost:27017/scamsathi"
        )
        self.client: Optional[Any] = None
        self.db: Optional[Any] = None
        self.collection: Optional[Any] = None
        self.is_connected = False
        self._lock = threading.Lock()

        # In-memory fallback storage
        self._memory_threats: deque = deque(maxlen=200)

        # Attempt MongoDB connection with 1.5s timeout
        self._init_mongo()

        # Seed realistic threat trends if storage is empty
        self._seed_initial_intel()

    def _init_mongo(self) -> None:
        """Attempt to establish a resilient MongoDB connection."""
        if not PYMONGO_AVAILABLE:
            self.is_connected = False
            return

        try:
            self.client = MongoClient(
                self.mongo_uri,
                serverSelectionTimeoutMS=1500,
                connectTimeoutMS=1500,
            )
            # Ping the admin database to verify connectivity
            self.client.admin.command("ping")
            self.db = self.client.get_default_database("scamsathi")
            self.collection = self.db["threat_intel"]
            # Create indexing for efficient queries
            self.collection.create_index([("timestamp", DESCENDING)])
            self.is_connected = True
        except Exception:
            self.is_connected = False
            self.client = None
            self.db = None
            self.collection = None

    def _seed_initial_intel(self) -> None:
        """Seed representative community scam trends so radar is informative on startup."""
        if self.get_total_count() > 0:
            return

        sample_threats = [
            {
                "threat_type": "phishing_message",
                "category": "HIGH",
                "score": 90,
                "threat_indicators": ["Account Suspension Threat", "Credential / OTP Harvesting Request", "Manufactured Urgency"],
                "target_brand": "State Bank of India",
                "domain": "sbi-kyc-verify.invalid",
                "summary": "Urgent SMS claiming bank account blocked; demands OTP to restore access.",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
            {
                "threat_type": "phishing_message",
                "category": "HIGH",
                "score": 85,
                "threat_indicators": ["Prize / Lottery / Reward Claim", "Advance Fee / Processing Charge Demand"],
                "target_brand": "Lucky Draw Rewards",
                "domain": "claim-reward-online.invalid",
                "summary": "Won ₹50,000 cash reward; asks for ₹999 processing charge deposit.",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
            {
                "threat_type": "suspicious_url",
                "category": "HIGH",
                "score": 80,
                "threat_indicators": ["Brand Spoofing / Impersonation", "Deceptive User-Info Syntax (@ Symbol)"],
                "target_brand": "HDFC Bank",
                "domain": "login-hdfc.invalid",
                "summary": "Spoofed banking portal using look-alike domain to harvest netbanking passwords.",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
            {
                "threat_type": "phishing_message",
                "category": "HIGH",
                "score": 75,
                "threat_indicators": ["Manufactured Urgency", "Account Suspension Threat"],
                "target_brand": "State Electricity Board",
                "domain": "None",
                "summary": "Fake electricity disconnection alert threatening power cutoff tonight at 9:30 PM.",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
            {
                "threat_type": "suspicious_url",
                "category": "MEDIUM",
                "score": 55,
                "threat_indicators": ["URL Shortener Service", "Credential / Verification Lures in URL"],
                "target_brand": "Unknown Courier",
                "domain": "bit.ly/track-package-delivery",
                "summary": "Shortened link concealing delivery tracking destination.",
                "timestamp": datetime.now(timezone.utc).isoformat(),
            },
        ]

        for item in sample_threats:
            self._save_record(item)

    def record_threat(
        self,
        threat_type: str,
        category: str,
        score: int,
        indicators: List[str],
        domain: Optional[str] = None,
        target_brand: Optional[str] = None,
        summary: Optional[str] = None,
    ) -> Dict[str, Any]:
        """
        Record a sanitized, anonymous threat entry.
        Never stores user-controlled raw message content.
        """
        record = {
            "threat_type": threat_type,
            "category": category,
            "score": score,
            "threat_indicators": indicators[:5],
            "domain": domain or "None",
            "target_brand": target_brand or "Generic Scam",
            "summary": summary or f"{category} risk threat detected with {len(indicators)} red flags.",
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }
        self._save_record(record)
        return record

    def _save_record(self, record: Dict[str, Any]) -> None:
        """Save to MongoDB if connected, else store in thread-safe memory deque."""
        if self.is_connected and self.collection is not None:
            try:
                self.collection.insert_one(dict(record))
                return
            except Exception:
                # If connection dropped, fallback to memory
                self.is_connected = False

        with self._lock:
            self._memory_threats.appendleft(record)

    def get_recent_threats(self, limit: int = 8) -> List[Dict[str, Any]]:
        """Retrieve recent threat entries."""
        if self.is_connected and self.collection is not None:
            try:
                cursor = self.collection.find({}, {"_id": 0}).sort("timestamp", DESCENDING).limit(limit)
                return list(cursor)
            except Exception:
                self.is_connected = False

        with self._lock:
            return list(self._memory_threats)[:limit]

    def get_total_count(self) -> int:
        """Return total threats recorded."""
        if self.is_connected and self.collection is not None:
            try:
                return self.collection.count_documents({})
            except Exception:
                self.is_connected = False
        return len(self._memory_threats)

    def get_threat_stats(self) -> Dict[str, Any]:
        """Calculate high-level threat trends and statistics."""
        threats = self.get_recent_threats(limit=100)
        high_count = sum(1 for t in threats if t.get("category") == "HIGH")
        medium_count = sum(1 for t in threats if t.get("category") == "MEDIUM")
        low_count = sum(1 for t in threats if t.get("category") == "LOW")

        # Top scam categories
        ind_counts: Dict[str, int] = {}
        for t in threats:
            for ind in t.get("threat_indicators", []):
                ind_counts[ind] = ind_counts.get(ind, 0) + 1

        top_indicators = sorted(ind_counts.items(), key=lambda x: x[1], reverse=True)[:4]

        return {
            "total_analyzed": len(threats),
            "high_risk_count": high_count,
            "medium_risk_count": medium_count,
            "low_risk_count": low_count,
            "top_threat_patterns": [
                {"name": name, "count": count} for name, count in top_indicators
            ],
            "storage_mode": "MongoDB (Connected)" if self.is_connected else "In-Memory Buffer (Privacy Mode)",
            "is_mongo_connected": self.is_connected,
        }

    def clear_memory(self) -> None:
        """Clear in-memory buffer (useful for unit tests)."""
        with self._lock:
            self._memory_threats.clear()


# Default singleton instance
db_instance = ThreatIntelDB()
