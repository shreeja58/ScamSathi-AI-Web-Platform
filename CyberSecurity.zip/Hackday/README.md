# ScamSathi AI (स्कैम साथी)
> **Detect the Scam. Expose the Trap. Protect Your Privacy.**

[![Python 3.10+](https://img.shields.io/badge/Python-3.10%2B-blue.svg)](https://www.python.org/)
[![Flask 3.x](https://img.shields.io/badge/Flask-3.1-black.svg)](https://flask.palletsprojects.com/)
[![Tests Passing](https://img.shields.io/badge/Tests-29%2F29%20Passed-emerald.svg)](https://pytest.org/)
[![Privacy First](https://img.shields.io/badge/Privacy-100%25%20Offline%20%26%20Zero%20Logs-cyan.svg)](#privacy--security-architecture)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)

---

## 1. Project Overview & Problem Statement

In India and across developing digital economies, cyber fraud has reached epidemic levels:
- Over **₹7,066 Crores** was lost to digital financial fraud in India in a single year.
- Millions of citizens, senior citizens, students, and workers receive deceptive WhatsApp messages, fake courier delivery SMS alerts, threats of electricity disconnection, fake KYC updates, and bogus part-time job lures daily.
- Attackers weaponize **manufactured panic** (*"Account blocked today!"*) and deceptive web links.
- Emerging social engineering attacks trick victims into opening fake verification pages that request **browser camera permissions** to harvest biometric face scans and surroundings for deepfakes and extortion.

Existing enterprise security tools are expensive, opaque black-boxes, or require uploading private messages to cloud servers.

**ScamSathi AI** is a privacy-first, explainable cybersecurity awareness web platform designed for everyday internet users. It empowers users to:
1. **Analyze suspicious messages** with transparent, explainable heuristic scoring.
2. **Deconstruct dangerous URLs 100% offline** without ever connecting to or pinging the attacker's server.
3. **Experience a safe camera-permission phishing simulator** to understand browser hardware manipulation with **zero real camera access**.
4. **Learn concrete defense habits** and know where to report scams immediately (National Cyber Crime Helpline: **1930** / **cybercrime.gov.in**).

---

## 2. Key Capabilities & Modules

### ✉️ Module 1: AI Phishing & Scam Message Detector
- **Input:** Paste SMS, WhatsApp messages, emails, telegram job offers, or electricity disconnection notices.
- **Explainable Rules & Contextual Scoring (0–100):**
  - **Manufactured Urgency:** Detects panic triggers (*"within 2 hours"*, *"today only"*).
  - **Suspension / Blocking Threats:** Identifies threats to accounts, SIM cards, or utility connections.
  - **Prize & Lottery Lures:** Detects unrealistic rewards (*"Won ₹50,000"*).
  - **Advance Fee Demands:** Catches upfront "processing charges" or "refundable registration fees".
  - **Credential & OTP Harvesting:** Highlights illegal requests for OTPs, PINs, CVVs, or passwords.
  - **Context-Aware Negation:** Correctly recognizes legitimate bank advisories (*"Your bank will never ask you to share your OTP..."*) without triggering false positives.
- **Results:** Visual risk meter (LOW: 0–29, MEDIUM: 30–59, HIGH: 60–100), safely escaped HTML highlighted evidence, human-readable explanations, and tailored safety recommendations.

### 🔗 Module 2: Suspicious URL Analyzer (100% Offline)
- **Zero-Network Guarantee:** Operates strictly on string parsing via `urllib.parse`, `ipaddress`, and regular expressions. Never makes HTTP requests, downloads files, or performs DNS lookups.
- **Threat Indicators:**
  - **Raw IP Hostnames:** Flags numerical/hex IPs used by phishers to bypass domain registration filters.
  - **Brand Spoofing & Typosquatting:** Flags unauthorized mentions of banks (SBI, HDFC, ICICI, Paytm) and look-alikes (`paytrm`, `arnazon`, `micros0ft`).
  - **Deceptive User-Info Syntax:** Detects the `@` trick (`http://google.com@attacker-site.invalid/`).
  - **URL Shortener Concealment:** Identifies `bit.ly`, `tinyurl.com`, `t.co`, etc.
  - **Excessive Subdomain Stacking:** Flags deep subdomain chains designed to push the real domain off-screen on smartphones.
  - **HTTPS ≠ Safe Reality Check:** Explains to users that an HTTPS padlock only encrypts transport and does not guarantee the honesty of the website owner.

### 📷 Module 3: Camera-Phishing Awareness Simulator
- **Strict Sandbox Requirement:** **No real camera or webcam APIs (`getUserMedia`) are ever called.**
- **Interactive 4-Step Educational Walkthrough:**
  - **Screen 1 (The Lure):** Shows a realistic fictional delivery SMS (*"Your parcel could not be delivered. Open verification link."*) and explains why delivery scams succeed.
  - **Screen 2 (The Deceptive Portal):** Simulates a fake courier tracking page with an HTML/CSS browser permission prompt (*"wants to use your camera"*). Provides "Simulate Allow" and "Simulate Deny" buttons.
  - **Screen 3 (Risk Breakdown):** 
    - If user simulates Allow: explains risks of biometric harvesting, deepfake synthesis, ambient espionage, and extortion.
    - If user simulates Deny: reinforces the correct security posture and explains how real browser permissions work.
  - **Screen 4 (Defense Checklist):** 6-point actionable defense checklist and permission revocation guide in browser settings.

---

## 3. Architecture & Request Flow

```mermaid
flowchart TD
    User([User / Browser])
    
    subgraph Frontend [Presentation Layer - HTML5 / CSS3 / Vanilla JS]
        Dashboard["Dashboard Landing Page"]
        MsgView["Message Detector UI"]
        UrlView["URL Analyzer UI"]
        SimView["Camera Phishing Simulator UI (Pure DOM)"]
    end
    
    subgraph Backend [Flask Application Server]
        Router["Flask Router & CSRF Guard"]
        Sanitizer["Input Sanitizer & Length Validator"]
        MsgEngine["MessageDetector Engine"]
        UrlEngine["URLAnalyzer Engine"]
        SafetyMiddle["Security Headers Middleware (CSP, HSTS, X-Frame)"]
    end

    User -->|Visits| Dashboard
    User -->|Submits Text| MsgView
    User -->|Submits URL| UrlView
    User -->|Interacts| SimView
    
    MsgView -->|POST Request| Router
    UrlView -->|POST Request| Router
    
    Router --> Sanitizer
    Sanitizer --> MsgEngine
    Sanitizer --> UrlEngine
    
    MsgEngine -->|Explainable Score 0-100| MsgView
    UrlEngine -->|Offline Structural Findings| UrlView
    SafetyMiddle --> User
```

---

## 4. Technology Stack

- **Backend:** Python 3.10+ with [Flask 3.1](https://flask.palletsprojects.com/)
- **Analysis Engine:** Python standard library (`re`, `urllib.parse`, `ipaddress`, `html`) — zero cloud API dependency.
- **Frontend:** Responsive HTML5, CSS3 (Modern dark-navy cybersecurity aesthetic), Vanilla ES6 JavaScript.
- **Testing:** [pytest](https://pytest.org/) automated test suite (29 test cases).
- **Security:** CSRF verification tokens, XSS HTML escaping, strict Content Security Policy (`CSP`), frame denial (`DENY`), and zero server-side data persistence.

---

## 5. Project Directory Structure

```text
scamsathi-ai/
├── app.py                      # Flask application factory, routes, and security headers
├── config.py                   # Environment configuration, secrets, and test flags
├── requirements.txt            # Python dependencies
├── README.md                   # Complete documentation
├── DEMO_GUIDE.md               # 3-minute hackathon presentation script & Judge Q&As
├── .gitignore                  # Git ignore rules
├── detectors/
│   ├── __init__.py             # Module exports
│   ├── message_detector.py     # Context-aware phishing message heuristic analyzer
│   └── url_analyzer.py         # 100% offline string-based URL analyzer
├── tests/
│   ├── __init__.py             # Test package initializer
│   ├── test_message_detector.py # Scenarios, advisories, edge cases, XSS escaping tests
│   ├── test_url_analyzer.py    # URL parsing, IP, brand spoofing, offline guarantee tests
│   └── test_routes.py          # Route tests, CSRF, error pages, and camera safety test
├── templates/
│   ├── base.html               # Shared layout, cyber navigation, helpline, and footer
│   ├── index.html              # Main dashboard with problem statement and how-it-works
│   ├── message_detector.html   # Module 1 UI with sample loader and highlighted preview
│   ├── url_analyzer.html       # Module 2 UI with URL breakdown and HTTPS reality check
│   ├── camera_simulator.html   # Module 3 interactive 4-stage educational sandbox
│   └── error.html              # Friendly error page (400, 404, 500) without tracebacks
└── static/
    ├── css/
    │   └── style.css           # Custom dark cybersecurity styling
    ├── js/
    │   └── app.js              # Client state machine, scenario loaders, and accordion
    └── images/
        └── logo.svg            # Custom SVG vector brand logo
```

---

## 6. Installation & Execution (Windows PowerShell)

Follow these exact steps to run ScamSathi AI on Windows:

### Step 1: Open PowerShell and navigate to the project root
```powershell
cd d:\Hackday
```

### Step 2: (Optional) Create and Activate Virtual Environment
```powershell
python -m venv venv
.\venv\Scripts\Activate.ps1
```

### Step 3: Install Dependencies
```powershell
pip install -r requirements.txt
```

### Step 4: Run Automated Tests
```powershell
python -m pytest -v
```
*(All 29 automated tests will run and pass in under 2 seconds).*

### Step 5: Start the Web Application
```powershell
python app.py
```

### Step 6: Access ScamSathi AI in your browser
Open: **[http://127.0.0.1:5000](http://127.0.0.1:5000)**

---

## 7. Testing & Verification Summary

The project includes 29 rigorous unit and integration tests covering:
- **Suspicious Example A:** Bank blocking threat + verification URL + OTP request $\rightarrow$ **HIGH RISK (Score $\ge$ 60)**.
- **Suspicious Example B:** ₹50,000 reward + ₹999 advance processing charge $\rightarrow$ **HIGH RISK (Score $\ge$ 60)**.
- **Legitimate Example:** Routine doctor appointment $\rightarrow$ **LOW RISK (Score $\le$ 29)**.
- **Legitimate Security Advisory:** Bank advisory warning *"Your bank will never ask you to share your OTP..."* $\rightarrow$ **LOW RISK (Score $\le$ 29)** without triggering false-positive alerts.
- **URL Inspection Checks:** IP hostnames, typosquatting (`sbi-verify.invalid`), URL shorteners (`bit.ly`), `@` user-info obfuscation, and rejection of dangerous `javascript:` and `file:` schemes.
- **100% Offline Guarantee:** Verifies that zero network sockets or URL openings occur during analysis.
- **Camera Safety Guarantee:** Inspects codebase to assert zero usage of `getUserMedia` or hardware webcam APIs.

---

## 8. Privacy & Security Protections

1. **In-Memory Heuristics:** Analysis is processed strictly in temporary RAM. No messages or URLs are saved to databases or disk logs.
2. **Zero Third-Party Telemetry:** Does not send user data to OpenAI, Google, or any external analytics service.
3. **Defense Against XSS:** All user input is safely sanitized using `html.escape()` and Jinja2 autoescaping before rendering highlighted words.
4. **CSRF Protection:** Cryptographic anti-CSRF tokens guard all state-changing POST forms and API endpoints.
5. **Hardened HTTP Headers:** Enforces `Content-Security-Policy`, `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, and `Referrer-Policy`.
6. **No Remote Code Execution / Network Traps:** URLs are analyzed strictly as text strings; the server never connects to external web addresses.

---

## 9. Known Limitations & Roadmap

### Known Limitations
- **Evasion by Novel Obfuscation:** Attackers using non-Latin Unicode homoglyphs (e.g. Cyrillic `а` instead of Latin `a`) or OCR-only image text may evade basic string heuristics.
- **Static Heuristics:** The system cannot determine if a newly registered, non-spoofed domain hosts malicious content without visiting it (visiting is intentionally avoided for safety).
- **English & Hinglish Focus:** The current regex dictionary is tuned for English and common Indian English/Hinglish phrasing.

### Future Roadmap
- [ ] **On-Device Multilingual NLP:** Integrate a tiny, local ONNX model (e.g. IndicBERT) for native Hindi, Tamil, Telugu, and Bengali message classification.
- [ ] **Screenshot Optical Character Recognition (OCR):** Add local Tesseract OCR to allow users to upload screenshots of WhatsApp conversations without sending images to the cloud.
- [ ] **Browser Extension (ScamSathi Shield):** Package the offline URL heuristic engine into a lightweight Chrome/Firefox extension that alerts users before they submit permissions on untrusted sites.

---

## 10. Responsible Use & Educational Disclaimer

ScamSathi AI is designed solely for **cybersecurity education, awareness, and defensive threat analysis**.
- Risk scores generated by this application are heuristic indicators and do not constitute legal or cryptographic guarantees of safety or fraud.
- Users must always exercise independent diligence, protect authentication secrets, and report actual fraud incidents to official law enforcement bodies (**National Cyber Crime Helpline: 1930** / **[cybercrime.gov.in](https://cybercrime.gov.in)**).
