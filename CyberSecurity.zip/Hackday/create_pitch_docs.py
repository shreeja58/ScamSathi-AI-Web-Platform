"""
Generate:
1. Team_5_Members_Pitch_Script.docx (Word document for 5-member team presentation)
2. Hackathon_Judge_Questions_and_Answers.pdf (Comprehensive PDF Q&A cheat sheet)
"""

import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import nsdecls, qn

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate,
    Paragraph,
    Spacer,
    Table,
    TableStyle,
    KeepTogether,
    HRFlowable,
)
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle


def set_cell_background(cell, fill_hex):
    """Set background color for docx table cell."""
    tcPr = cell._element.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)


def create_team_pitch_docx(filename="Team_5_Members_Pitch_Script.docx"):
    doc = docx.Document()

    # Page Margins
    for section in doc.sections:
        section.top_margin = Inches(0.8)
        section.bottom_margin = Inches(0.8)
        section.left_margin = Inches(0.8)
        section.right_margin = Inches(0.8)

    # Styles & Colors
    C_NAVY = RGBColor(11, 15, 25)
    C_CYAN = RGBColor(6, 182, 212)
    C_TEAL = RGBColor(20, 184, 166)
    C_GRAY = RGBColor(100, 116, 139)

    # Document Header
    p_badge = doc.add_paragraph()
    r_badge = p_badge.add_run("NATIONAL CYBER DEFENSE HACKATHON 2026 • 5-MEMBER TEAM GUIDE")
    r_badge.font.name = "Arial"
    r_badge.font.size = Pt(9.5)
    r_badge.font.bold = True
    r_badge.font.color.rgb = C_CYAN

    p_title = doc.add_paragraph()
    r_title = p_title.add_run("ScamSathi AI — 5-Member Team Pitch Script")
    r_title.font.name = "Arial"
    r_title.font.size = Pt(24)
    r_title.font.bold = True
    r_title.font.color.rgb = C_NAVY

    p_sub = doc.add_paragraph()
    r_sub = p_sub.add_run("Turn-by-turn presentation script, screen cues, verbal handoffs, and role distribution to impress judges.")
    r_sub.font.name = "Arial"
    r_sub.font.size = Pt(11)
    r_sub.font.italic = True
    r_sub.font.color.rgb = C_GRAY

    doc.add_paragraph().paragraph_format.space_after = Pt(10)

    # Summary Table of Roles
    table = doc.add_table(rows=1, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr_cells = table.rows[0].cells
    headers = ["Speaker", "Assigned Module / Role", "Time Slot", "Key Focus to Deliver"]
    for i, h in enumerate(headers):
        hdr_cells[i].text = h
        set_cell_background(hdr_cells[i], "0B0F19")
        p = hdr_cells[i].paragraphs[0]
        p.runs[0].font.name = "Arial"
        p.runs[0].font.bold = True
        p.runs[0].font.color.rgb = RGBColor(255, 255, 255)
        p.runs[0].font.size = Pt(9.5)

    team_data = [
        ("Member 1", "Team Lead: Problem Statement & Hook", "0:00 – 0:45", "India's ₹7,000+ Cr crisis, why current tools fail, vision."),
        ("Member 2", "AI Phishing Message Detector Lead", "0:45 – 1:30", "Live demo of Suspicious A vs Bank Advisory (False positive resistance)."),
        ("Member 3", "Suspicious URL Analyzer Lead", "1:30 – 2:15", "100% offline inspection, raw IPs, brand spoofing, HTTPS myth."),
        ("Member 4", "Camera Phishing Simulator Lead", "2:15 – 3:00", "Delivery scam lure, pure HTML/CSS prompt, deepfake risk education."),
        ("Member 5", "Full-Stack, MongoDB & Impact Lead", "3:00 – 3:45", "Flask architecture, MongoDB telemetry API, 33/33 tests, Q&A invite."),
    ]

    for speaker, role, time_slot, focus in team_data:
        row_cells = table.add_row().cells
        row_cells[0].text = speaker
        row_cells[1].text = role
        row_cells[2].text = time_slot
        row_cells[3].text = focus
        set_cell_background(row_cells[0], "F1F5F9")
        for idx in range(4):
            p = row_cells[idx].paragraphs[0]
            if p.runs:
                p.runs[0].font.name = "Arial"
                p.runs[0].font.size = Pt(9)

    doc.add_paragraph().paragraph_format.space_after = Pt(14)

    # =========================================================================
    # DETAILED ROLES & SCRIPTS
    # =========================================================================
    members = [
        {
            "member": "MEMBER 1: TEAM LEAD — HOOK & PROBLEM STATEMENT",
            "time": "0:00 – 0:45 (45 Seconds)",
            "screen_action": "Show ScamSathi AI Landing Dashboard (http://127.0.0.1:5000/). Point to the tagline and problem cards.",
            "script": (
                "\"Good morning respected judges! In India today, digital fraud is no longer just a technical nuisance—it is an economic catastrophe. "
                "Over ₹7,000 Crores was drained from everyday citizens in a single year through urgent WhatsApp forwards, fake electricity disconnection warnings, "
                "and courier scam alerts.\n\n"
                "The core problem is that scammers weaponize manufactured panic, forcing victims into acting before thinking. "
                "Meanwhile, existing antivirus and scam tools are opaque black-boxes that say 'safe' or 'unsafe' without explaining why, "
                "or they force users to upload private chats to foreign cloud servers.\n\n"
                "We built ScamSathi AI: an explainable, 100% privacy-first cybersecurity platform that detects scams, inspects URLs safely offline, "
                "and inoculates citizens against emerging camera-permission traps.\n\n"
                "To demonstrate our first defense module, I now pass to [Member 2's Name] to analyze live phishing messages.\""
            ),
            "handoff": "Seamlessly step to the side and hand presentation focus to Member 2. Keep the laptop display centered.",
        },
        {
            "member": "MEMBER 2: AI PHISHING MESSAGE DETECTOR SPECIALIST",
            "time": "0:45 – 1:30 (45 Seconds)",
            "screen_action": "Navigate to Message Detector (/detect/message). Load 'Suspicious A: Bank Blocking & OTP Demand', click Analyze. Then load 'Legitimate Security: Official Bank Advisory', click Analyze.",
            "script": (
                "\"Thank you, [Member 1's Name]. Judges, when a victim receives a scam message, they need explainable clarity, not a random guess.\n\n"
                "Here, I'm loading a classic high-pressure scam: 'URGENT! Your bank account will be blocked today. Verify immediately and send your OTP.' "
                "With one click, ScamSathi's contextual heuristic engine analyzes the text in under 5 milliseconds, scoring it as HIGH RISK (90/100). "
                "Notice that our UI highlights the exact danger words in safe HTML, explains the psychological urgency trigger, and gives direct action steps.\n\n"
                "Now, here is what sets ScamSathi AI apart from naive keyword tools. I will load an official bank advisory: 'Your bank will never ask you to share your OTP or PIN.' "
                "Even though this text contains 'bank', 'OTP', and 'PIN', our context-aware negation engine recognizes this as legitimate security advice and scores it in the safe LOW RISK green band. "
                "Zero false positives.\n\n"
                "Next, how do we inspect the malicious links inside these messages without risking malware? Over to [Member 3's Name] for our URL Analyzer.\""
            ),
            "handoff": "Point to the URL Analyzer navigation link and pass to Member 3.",
        },
        {
            "member": "MEMBER 3: SUSPICIOUS URL ANALYZER SPECIALIST",
            "time": "1:30 – 2:15 (45 Seconds)",
            "screen_action": "Navigate to URL Analyzer (/detect/url). Load 'Brand Spoofing: http://sbi-account-verify.invalid/update-kyc', click Analyze. Point out the parsed anatomy and the 'Why HTTPS != Safe' educational card.",
            "script": (
                "\"Thank you, [Member 2's Name]. Opening an unknown link is like walking into a trap. Traditional URL scanners make the dangerous mistake of pinging or crawling the submitted link—which alerts the attacker, exposes the victim's IP address, and risks drive-by malware downloads.\n\n"
                "ScamSathi AI operates on a 100% Zero-Network Guarantee. We inspect links entirely offline using Python string decomposition and IP verification, without sending a single network packet to the remote host.\n\n"
                "Here, we analyze 'sbi-account-verify.invalid'. ScamSathi immediately exposes that an unauthorized domain is impersonating the State Bank of India brand. We flag raw IP addresses, hidden URL shorteners, and deceptive user-info '@' syntax.\n\n"
                "Most importantly, we bust the #1 misconception among ordinary users: that an HTTPS padlock means a website is safe. Our educational callout explains that phishers use free SSL certificates too; encryption in transit does not equal website honesty.\n\n"
                "Now, to show how we tackle emerging hardware permission scams, I pass to [Member 4's Name].\""
            ),
            "handoff": "Navigate to the Camera Simulator tab and hand over to Member 4.",
        },
        {
            "member": "MEMBER 4: CAMERA-PHISHING AWARENESS SIMULATOR SPECIALIST",
            "time": "2:15 – 3:00 (45 Seconds)",
            "screen_action": "On the Camera Simulator page (/simulator), click 'Simulate Clicking the Link'. Show the mock browser prompt, click 'Simulate Allow' to show biometric risks, then click 'View Protection Checklist'.",
            "script": (
                "\"Thank you, [Member 3's Name]. Criminals are constantly evolving. An emerging vector in India is Camera-Permission Phishing. Attackers send fake delivery notices claiming: 'Your package could not be delivered, open link to verify identity'. When opened, the page demands camera access to 'scan your face'. Once granted, scammers capture facial video to defeat banking selfie-KYC, train AI deepfakes, or extort victims.\n\n"
                "ScamSathi AI features India's first Camera-Phishing Awareness Sandbox. As you see on the screen, this is strictly educational—our codebase contains ZERO camera APIs or getUserMedia calls.\n\n"
                "When the user interacts with our simulated delivery portal, they see a mock browser permission prompt. If they click 'Simulate Allow', our system demonstrates how their biometrics could be harvested. If they click 'Simulate Deny', it reinforces that no delivery courier ever legitimately needs your webcam!\n\n"
                "It finishes with an actionable 6-point checklist teaching users how to audit and revoke permissions in their browser settings.\n\n"
                "To discuss our full-stack engineering, MongoDB telemetry, and social impact, here is [Member 5's Name].\""
            ),
            "handoff": "Step to the side and gesture to Member 5 for the technical and concluding pitch.",
        },
        {
            "member": "MEMBER 5: FULL-STACK, MONGODB THREAT INTEL & IMPACT LEAD",
            "time": "3:00 – 3:45 (45 Seconds)",
            "screen_action": "Scroll to the Live Community Threat Radar on the Dashboard. Point to the 'MongoDB / In-Memory' status pill and the recent threats table. Then show the test suite terminal output (33/33 passed).",
            "script": (
                "\"Thank you, [Member 4's Name]. Behind this platform is a hardened full-stack architecture built with Python Flask and MongoDB.\n\n"
                "On our dashboard, you see our Live Community Threat Intelligence Radar. Every time a scam is detected, sanitized threat metadata—such as the spoofed domain and attack category—is aggregated via our '/api/threat-intel' REST API. In strict compliance with India's DPDP Act, we never store user messages, phone numbers, or private data.\n\n"
                "Crucially, our database layer features a zero-crash dual mode: it seamlessly leverages MongoDB when connected, and automatically falls back to an in-memory buffer when offline, ensuring the application never crashes on any evaluation system.\n\n"
                "Our codebase is 100% complete with 33 out of 33 automated tests passing in under 2 seconds. Every screen integrates India's official 1930 Cyber Helpline.\n\n"
                "ScamSathi AI turns ordinary citizens from helpless victims into informed digital defenders. We are ready to answer your questions!\""
            ),
            "handoff": "All 5 members stand together, smile, and make direct eye contact with the judges.",
        },
    ]

    for m in members:
        # Header Box
        p_mh = doc.add_paragraph()
        p_mh.paragraph_format.space_before = Pt(14)
        p_mh.paragraph_format.space_after = Pt(2)
        r_mh = p_mh.add_run(f"▶ {m['member']}")
        r_mh.font.name = "Arial"
        r_mh.font.size = Pt(13)
        r_mh.font.bold = True
        r_mh.font.color.rgb = C_CYAN

        # Meta table
        mt = doc.add_table(rows=2, cols=2)
        mt.alignment = WD_TABLE_ALIGNMENT.CENTER
        mt.rows[0].cells[0].text = "⏱️ Time Allocated:"
        mt.rows[0].cells[1].text = m["time"]
        mt.rows[1].cells[0].text = "💻 Screen Action:"
        mt.rows[1].cells[1].text = m["screen_action"]

        for row in mt.rows:
            set_cell_background(row.cells[0], "F8FAFC")
            set_cell_background(row.cells[1], "F1F5F9")
            for c in row.cells:
                p = c.paragraphs[0]
                p.runs[0].font.name = "Arial"
                p.runs[0].font.size = Pt(9)
                p.runs[0].font.color.rgb = C_NAVY

        # Spoken Script
        p_sh = doc.add_paragraph()
        p_sh.paragraph_format.space_before = Pt(6)
        r_sh = p_sh.add_run("🎙️ Spoken Script (Memorize / Read confidently):")
        r_sh.font.bold = True
        r_sh.font.size = Pt(10)
        r_sh.font.color.rgb = C_TEAL

        p_script = doc.add_paragraph()
        p_script.paragraph_format.left_indent = Inches(0.2)
        r_scr = p_script.add_run(m["script"])
        r_scr.font.name = "Arial"
        r_scr.font.size = Pt(10)
        r_scr.font.color.rgb = C_NAVY

        # Verbal Handoff
        p_ho = doc.add_paragraph()
        r_ho = p_ho.add_run("🤝 Transition Handoff Tip: " + m["handoff"])
        r_ho.font.italic = True
        r_ho.font.size = Pt(9)
        r_ho.font.color.rgb = C_GRAY

    # =========================================================================
    # TEAM COORDINATION RULES
    # =========================================================================
    doc.add_page_break()
    p_sec = doc.add_paragraph()
    r_sec = p_sec.add_run("🏆 Winning Team Coordination Rules")
    r_sec.font.name = "Arial"
    r_sec.font.size = Pt(16)
    r_sec.font.bold = True
    r_sec.font.color.rgb = C_CYAN

    rules = [
        ("The Laptop Operator:", "Member 1 or Member 5 should operate the mouse/keyboard smoothly while Member 2, 3, and 4 speak. The speaker should NEVER look down at the keyboard; look directly at the judges!"),
        ("The 'We' Mentality:", "Never say 'my code' or 'his module'. Always say 'our team built', 'our heuristic engine', 'our security architecture'."),
        ("Handling Judge Interruptions:", "If a judge interrupts mid-pitch with a question, STOP speaking immediately, smile, and answer the question directly. Do NOT try to finish the memorized script first."),
        ("Q&A Tag-Team Strategy:", "Member 1 acts as traffic controller. If a technical question is asked about regex or URLs, Member 1 says: 'Great question. Our URL specialist, [Member 3], can walk you through the string parsing architecture.' This shows extraordinary team synergy."),
    ]

    for title, desc in rules:
        p_r = doc.add_paragraph()
        r_t = p_r.add_run(f"• {title} ")
        r_t.font.bold = True
        r_t.font.color.rgb = C_NAVY
        r_d = p_r.add_run(desc)
        r_d.font.color.rgb = C_GRAY

    output_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    doc.save(output_path)
    print(f"Word document saved to: {output_path}")


def create_judge_qa_pdf(filename="Hackathon_Judge_Questions_and_Answers.pdf"):
    pdf_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), filename)
    doc = SimpleDocTemplate(
        pdf_path,
        pagesize=letter,
        leftMargin=40,
        rightMargin=40,
        topMargin=40,
        bottomMargin=40,
    )

    styles = getSampleStyleSheet()

    # Custom styles
    title_style = ParagraphStyle(
        "DocTitle",
        parent=styles["Heading1"],
        fontName="Helvetica-Bold",
        fontSize=20,
        leading=24,
        textColor=colors.HexColor("#0B0F19"),
        spaceAfter=4,
    )

    subtitle_style = ParagraphStyle(
        "DocSubtitle",
        parent=styles["Normal"],
        fontName="Helvetica-Oblique",
        fontSize=10,
        leading=14,
        textColor=colors.HexColor("#64748B"),
        spaceAfter=14,
    )

    cat_style = ParagraphStyle(
        "CatHeader",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=13,
        leading=16,
        textColor=colors.HexColor("#06B6D4"),
        spaceBefore=12,
        spaceAfter=6,
    )

    q_style = ParagraphStyle(
        "QStyle",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=10.5,
        leading=14,
        textColor=colors.HexColor("#0F172A"),
        spaceBefore=6,
        spaceAfter=3,
    )

    speaker_tag_style = ParagraphStyle(
        "SpeakerTag",
        parent=styles["Normal"],
        fontName="Helvetica-Bold",
        fontSize=8.5,
        leading=11,
        textColor=colors.HexColor("#059669"),
        spaceAfter=3,
    )

    a_style = ParagraphStyle(
        "AStyle",
        parent=styles["Normal"],
        fontName="Helvetica",
        fontSize=9,
        leading=13,
        textColor=colors.HexColor("#334155"),
        spaceAfter=8,
    )

    story = []

    # Title Banner
    story.append(Paragraph("ScamSathi AI — Hackathon Judge Q&A Master Cheat Sheet", title_style))
    story.append(Paragraph("Anticipated questions across algorithms, security, database, and impact with 30-second model answers and team speaker assignments.", subtitle_style))
    story.append(HRFlowable(width="100%", thickness=1.5, color=colors.HexColor("#06B6D4"), spaceAfter=10))

    qa_sections = [
        {
            "category": "SECTION 1: ALGORITHMS, HEURISTICS & SCORING",
            "items": [
                (
                    "Q1: How does your 0–100 risk score work mathematically?",
                    "Assigned to: Member 2 (Message Detector Lead)",
                    "\"Our scoring engine uses transparent, additive weights based on verified cyber threat indicators. High-severity threats like OTP harvesting or advance fee demands add 30–35 points; secondary traits like urgency or brand mentions add 10–15 points. Crucially, we use composite synergy bonuses: if a threat combines an urgent suspension warning with an external verification link, it receives a +15 bonus. Scores are capped at 100 and mapped into three documented bands: Low (0–29), Medium (30–59), and High (60–100).\""
                ),
                (
                    "Q2: Why did you choose rule-based heuristics instead of a machine learning / LLM model?",
                    "Assigned to: Member 2 or Member 5",
                    "\"In cybersecurity awareness, explainability and speed are essential. An LLM is a black-box that hallucinates, takes 2–3 seconds per call, costs API fees, and leaks private user chats to cloud servers. Our explainable heuristic engine runs locally in under 5 milliseconds, requires zero GPU, costs ₹0, and highlights the exact coercion phrase for the user. We designed our architecture so a tiny local ONNX model can plug in as an optional secondary layer without compromising privacy.\""
                ),
                (
                    "Q3: How do you prevent false positives on legitimate bank security alerts?",
                    "Assigned to: Member 2 (Message Detector Lead)",
                    "\"Naive tools flag any message containing 'bank' or 'OTP'. We implemented contextual negation rules. When our engine detects advisory phrases like 'will never ask you to share your OTP' alongside official customer support instructions, it recognizes this as an anti-scam notice. It suppresses the credential penalty and classifies the message as Low Risk in the safe green band.\""
                ),
                (
                    "Q4: Can an attacker bypass your detector with leetspeak or unusual spelling?",
                    "Assigned to: Member 2 (Message Detector Lead)",
                    "\"While simple keyword filters fail against leetspeak, ScamSathi uses flexible regex boundary anchors and composite checks across multiple vectors (urgency + links + fee demands). Furthermore, our UI explicitly states that scores are indicative heuristics, not guarantees of safety. We teach users foundational defense principles—such as never sharing OTPs regardless of score.\""
                ),
            ]
        },
        {
            "category": "SECTION 2: URL ANALYSIS & ZERO-NETWORK SECURITY",
            "items": [
                (
                    "Q5: How do you analyze URLs without opening them or making network calls?",
                    "Assigned to: Member 3 (URL Analyzer Lead)",
                    "\"We inspect URLs through offline syntactic decomposition using Python's urllib.parse and ipaddress modules. We inspect the protocol scheme, check if the host is a raw IP or obfuscated hex IP, detect deceptive user-info '@' syntax, and match known shortening services. Because we never make HTTP connections or DNS lookups, the user's IP address is never revealed to the attacker.\""
                ),
                (
                    "Q6: Doesn't an HTTPS padlock mean a website is legitimate?",
                    "Assigned to: Member 3 (URL Analyzer Lead)",
                    "\"That is the #1 myth we actively bust! HTTPS only encrypts communication between the browser and server to protect against local Wi-Fi sniffers. Today, threat actors acquire free SSL certificates automatically via Let's Encrypt in seconds. Over 70% of active phishing sites now run on HTTPS. An encrypted connection does not mean the website owner is honest.\""
                ),
                (
                    "Q7: How do you detect brand spoofing and look-alike domains?",
                    "Assigned to: Member 3 (URL Analyzer Lead)",
                    "\"We maintain an offline dictionary of frequently targeted Indian institutions (SBI, HDFC, ICICI, Paytm, India Post) and inspect whether the brand name appears in an unauthorized domain or deep subdomain (e.g. 'sbi-verification-update.invalid'). We also check common typosquatting substitutions like 0 for o, 1 for l, and rn for m.\""
                ),
            ]
        },
        {
            "category": "SECTION 3: CAMERA PHISHING & HARDWARE SAFETY",
            "items": [
                (
                    "Q8: Does the Camera Simulator actually access the user's webcam?",
                    "Assigned to: Member 4 (Camera Simulator Lead)",
                    "\"Absolutely not. The simulator is built 100% in pure HTML and CSS with a client-side state machine. The browser permission pop-up is an HTML mockup designed to look like a browser dialog. We have an automated test (test_strict_no_real_camera_api_in_codebase) that programmatically verifies neither getUserMedia nor navigator.mediaDevices exists anywhere in the codebase.\""
                ),
                (
                    "Q9: Why is camera-permission phishing such a critical emerging threat?",
                    "Assigned to: Member 4 (Camera Simulator Lead)",
                    "\"Scammers trick users into granting camera permissions on fake delivery tracking pages under the guise of 'facial verification'. Once granted, they capture high-definition facial video to bypass selfie-based liveness verification on fintech apps, train AI deepfakes to impersonate victims in video calls to family, or conduct blackmail schemes.\""
                ),
            ]
        },
        {
            "category": "SECTION 4: DATABASE, ARCHITECTURE & PRIVACY",
            "items": [
                (
                    "Q10: Why did you choose MongoDB, and how is it used?",
                    "Assigned to: Member 5 (Full-Stack & Database Lead)",
                    "\"We use MongoDB via pymongo to power our live Community Threat Radar (/api/threat-intel). Crucially, to protect user privacy under India's DPDP Act, we never store user messages or phone numbers. We only persist sanitized threat signals—such as spoofed domain names, threat categories, and timestamps—to map real-time scam trends across India.\""
                ),
                (
                    "Q11: What happens if MongoDB is not running on an evaluator's machine?",
                    "Assigned to: Member 5 (Full-Stack & Database Lead)",
                    "\"We engineered a dual-mode zero-crash fallback. When MongoDB is available, it persists records; if MongoDB is unavailable, database.py automatically falls back to an in-memory buffer with a 1.5-second timeout. The application never throws an unhandled connection error and works flawlessly offline.\""
                ),
                (
                    "Q12: How does your system scale to handle millions of requests?",
                    "Assigned to: Member 5 (Full-Stack & Database Lead)",
                    "\"Because each analysis is stateless and completes in under 5 milliseconds without neural network inference, a standard 2-vCPU cloud container running Gunicorn can handle thousands of requests per second. Furthermore, our offline regex engine can be packaged as a client-side browser extension that runs directly on the user's device with zero backend server cost.\""
                ),
            ]
        },
        {
            "category": "SECTION 5: SOCIAL IMPACT & FUTURE ROADMAP",
            "items": [
                (
                    "Q13: What is the social impact of ScamSathi AI?",
                    "Assigned to: Member 1 or Member 5",
                    "\"ScamSathi AI democratizes digital safety for 800+ million Indian smartphone users—especially senior citizens, first-time internet users, and gig workers who are the prime targets of fake KYC and courier scams. By explaining why a trap is dangerous, it provides mental inoculation rather than opaque scores.\""
                ),
                (
                    "Q14: If you had 3 more months, what would you add next?",
                    "Assigned to: Member 1 (Team Lead)",
                    "\"Three high-value extensions: First, local on-device Indic language NLP (using IndicBERT via ONNX) for Hindi, Tamil, and Bengali. Second, client-side OCR (Tesseract.js) so senior citizens can simply upload a screenshot of a suspicious WhatsApp chat without typing. Third, releasing a Chrome/Firefox extension that automatically intercepts phishing delivery links.\""
                ),
            ]
        },
    ]

    for sec in qa_sections:
        story.append(Paragraph(sec["category"], cat_style))
        for q, speaker, a in sec["items"]:
            item_story = [
                Paragraph(q, q_style),
                Paragraph(f"<b>{speaker}</b>", speaker_tag_style),
                Paragraph(a, a_style),
                Spacer(1, 4),
            ]
            story.append(KeepTogether(item_story))
        story.append(Spacer(1, 6))

    doc.build(story)
    print(f"PDF document saved to: {pdf_path}")


if __name__ == "__main__":
    create_team_pitch_docx()
    create_judge_qa_pdf()
