"""
Automated unit tests for ScamSathi AI URL Analyzer.
Verifies syntax checks, IP detection, shorteners, user-info tricks,
dangerous scheme rejection, and 100% offline guarantee.
"""

from unittest.mock import patch
import pytest
from detectors.url_analyzer import URLAnalyzer, analyze_url


@pytest.fixture
def analyzer():
    return URLAnalyzer()


def test_valid_https_url_parsed_clean(analyzer):
    """Valid standard HTTPS website should score LOW and recognize HTTPS."""
    url = "https://cybercrime.gov.in/Webform/Crime_AuthoLogin.aspx"
    result = analyzer.analyze(url)

    assert result["is_valid"] is True
    assert result["category"] == "LOW"
    assert result["score"] <= 29
    assert result["parsed"]["scheme"] == "https"
    assert result["parsed"]["hostname"] == "cybercrime.gov.in"
    assert any("Encrypted Transport" in p for p in result["positive_indicators"])


def test_raw_ip_address_hostname(analyzer):
    """Raw IP addresses used as web hosts should receive a high risk score."""
    url = "http://185.220.101.5/banking/login.php"
    result = analyzer.analyze(url)

    assert result["category"] in ("MEDIUM", "HIGH")
    assert result["score"] >= 40
    indicator_names = [ind["name"] for ind in result["risk_indicators"]]
    assert any("Raw IP Address" in name for name in indicator_names)


def test_url_shortener_service(analyzer):
    """Shorteners like bit.ly, tinyurl.com should be flagged for obscuring destination."""
    url = "https://bit.ly/3xFakeReward"
    result = analyzer.analyze(url)

    indicator_names = [ind["name"] for ind in result["risk_indicators"]]
    assert any("URL Shortener" in name for name in indicator_names)


def test_userinfo_deception_syntax(analyzer):
    """Deceptive userinfo '@' symbol trick should be flagged as high severity."""
    url = "http://google.com@attacker-site.invalid/signin"
    result = analyzer.analyze(url)

    indicator_names = [ind["name"] for ind in result["risk_indicators"]]
    assert any("User-Info" in name for name in indicator_names)
    assert result["score"] >= 40


def test_excessive_subdomains(analyzer):
    """Deep chain of subdomains designed to conceal the root domain on mobile displays."""
    url = "http://verify.account.security.service.tracker.top/auth"
    result = analyzer.analyze(url)

    indicator_names = [ind["name"] for ind in result["risk_indicators"]]
    assert any("Excessive Subdomain" in name for name in indicator_names)
    assert any("High-Risk Top-Level Domain" in name for name in indicator_names)


def test_brand_spoofing_detection(analyzer):
    """Impersonation of trusted banks or brands in suspicious domains."""
    url = "http://sbi-account-verify.invalid/update-kyc"
    result = analyzer.analyze(url)

    assert result["category"] in ("MEDIUM", "HIGH")
    indicator_names = [ind["name"] for ind in result["risk_indicators"]]
    assert any("Brand Spoofing" in name for name in indicator_names)


def test_dangerous_schemes_rejected(analyzer):
    """Schemes like javascript: and file: must be flagged as critical hazards."""
    js_url = "javascript:alert(document.cookie)"
    js_res = analyzer.analyze(js_url)
    assert js_res["category"] == "HIGH"
    assert js_res["score"] >= 90
    assert js_res["is_valid"] is False

    file_url = "file:///etc/passwd"
    file_res = analyzer.analyze(file_url)
    assert file_res["category"] == "HIGH"
    assert file_res["score"] >= 90


def test_empty_and_corrupt_urls(analyzer):
    """Empty or whitespace inputs handled safely."""
    res_empty = analyzer.analyze("")
    assert res_empty["category"] == "LOW"
    assert res_empty["score"] == 0

    res_spaces = analyzer.analyze("   ")
    assert res_spaces["category"] == "LOW"
    assert res_spaces["score"] == 0


def test_strictly_zero_network_calls(analyzer):
    """
    CRITICAL SAFETY REQUIREMENT:
    Verify that analyzer performs 100% offline string analysis and never makes network calls.
    """
    with patch("socket.socket.connect") as mock_connect, \
         patch("urllib.request.urlopen") as mock_urlopen:
        
        analyzer.analyze("https://malicious-test-example.invalid/phish")
        analyzer.analyze("http://192.168.1.1/admin")
        analyzer.analyze("http://google.com@attacker.invalid")

        # Zero network calls should have occurred
        assert mock_connect.call_count == 0
        assert mock_urlopen.call_count == 0


def test_singleton_convenience_function():
    """Verify analyze_url convenience helper."""
    res = analyze_url("https://onlinesbi.sbi")
    assert "score" in res
    assert "category" in res
    assert "parsed" in res
