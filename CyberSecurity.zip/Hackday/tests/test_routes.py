"""
Automated integration tests for ScamSathi AI web routes,
views, API endpoints, error handling, and camera safety guarantees.
"""

import os
import pytest
from app import create_app
from config import TestingConfig


@pytest.fixture
def app():
    app_instance = create_app(TestingConfig)
    return app_instance


@pytest.fixture
def client(app):
    return app.test_client()


def test_index_route(client):
    """Home dashboard renders successfully with tagline and navigation."""
    response = client.get("/")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "ScamSathi" in html
    assert "Detect the Scam. Expose the Trap. Protect Your Privacy." in html
    assert "AI Phishing Message Detector" in html
    assert "Suspicious URL Analyzer" in html
    assert "Camera-Phishing" in html


def test_message_detector_get(client):
    """Message detector page renders with form and sample options."""
    response = client.get("/detect/message")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "Analyze Message" in html
    assert "sampleSelector" in html


def test_message_detector_post(client):
    """POST submission to message detector returns parsed results."""
    payload = {
        "message": "URGENT! Your bank account will be blocked today. Verify immediately at http://bank-verify.invalid and send OTP."
    }
    response = client.post("/detect/message", data=payload)
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "HIGH RISK" in html
    assert "Analysis Explanation" in html


def test_url_analyzer_get(client):
    """URL analyzer page renders with input field and safety guarantee."""
    response = client.get("/detect/url")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "Inspect URL" in html
    assert "100% Offline" in html


def test_url_analyzer_post(client):
    """POST submission to URL analyzer returns parsed breakdown."""
    payload = {
        "url": "http://185.220.101.5/banking/login.php"
    }
    response = client.post("/detect/url", data=payload)
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "Raw IP Address" in html
    assert "URL Structural Breakdown" in html


def test_camera_simulator_route_and_disclaimer(client):
    """
    Simulator route must return 200 and explicitly include the mandatory disclaimer:
    'CYBERSECURITY TRAINING SIMULATION — NO REAL CAMERA ACCESS'
    """
    response = client.get("/simulator")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "CYBERSECURITY TRAINING SIMULATION — NO REAL CAMERA ACCESS" in html
    assert "Simulate Allow" in html
    assert "Simulate Deny" in html
    assert "Restart Training Simulation" in html


def test_strict_no_real_camera_api_in_codebase():
    """
    STRICT VERIFICATION:
    Ensure that neither the HTML template nor JavaScript calls getUserMedia,
    MediaDevices, or real webcam capture APIs.
    """
    base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    template_path = os.path.join(base_dir, "templates", "camera_simulator.html")
    js_path = os.path.join(base_dir, "static", "js", "app.js")

    with open(template_path, "r", encoding="utf-8") as f:
        template_content = f.read()

    with open(js_path, "r", encoding="utf-8") as f:
        js_content = f.read()

    # Neither file may contain real camera invocation calls
    assert "getUserMedia" not in template_content
    assert "navigator.mediaDevices" not in template_content
    assert "getUserMedia" not in js_content
    assert "navigator.mediaDevices" not in js_content


def test_api_analyze_message_json(client):
    """JSON API endpoint returns structured risk analysis."""
    data = {
        "message": "Congratulations! You won a ₹50,000 reward. Pay ₹999 processing charges to claim your prize."
    }
    response = client.post("/api/analyze-message", json=data)
    assert response.status_code == 200
    json_data = response.get_json()
    assert json_data["category"] == "HIGH"
    assert json_data["score"] >= 60
    assert "indicators" in json_data


def test_api_analyze_url_json(client):
    """JSON API endpoint for URL analysis returns components and indicators."""
    data = {"url": "https://cybercrime.gov.in"}
    response = client.post("/api/analyze-url", json=data)
    assert response.status_code == 200
    json_data = response.get_json()
    assert json_data["category"] == "LOW"
    assert json_data["parsed"]["scheme"] == "https"


def test_404_error_page(client):
    """Custom 404 page returns friendly error without exposing tracebacks."""
    response = client.get("/non-existent-page-xyz")
    assert response.status_code == 404
    html = response.get_data(as_text=True)
    assert "Error 404" in html
    assert "The requested page could not be found." in html
    assert "Traceback" not in html


def test_api_threat_intel(client):
    """API endpoint returns aggregated community threat telemetry."""
    response = client.get("/api/threat-intel")
    assert response.status_code == 200
    json_data = response.get_json()
    assert json_data["status"] == "success"
    assert "stats" in json_data
    assert "recent_threats" in json_data
    assert "database" in json_data


def test_explainer_route(client):
    """Animated 2-minute explainer page renders successfully."""
    response = client.get("/explainer")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "2-Minute Animated Story" in html
    assert "Play Story" in html


def test_how_it_works_route(client):
    """How It Works & Real-Time Case Studies page renders successfully."""
    response = client.get("/how-it-works")
    assert response.status_code == 200
    html = response.get_data(as_text=True)
    assert "How ScamSathi AI Works & Real-Time Case Studies" in html
    assert "The 4-Stage Privacy-First Defense Pipeline" in html
    assert "The \"Tonight 9:30 PM Electricity Bill Disconnection\" Trap" in html
    assert "Digital Arrest" in html
    assert "The \"Golden Hour\" Protocol" in html

