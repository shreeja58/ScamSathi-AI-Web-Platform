"""
Automated unit tests for ScamSathi AI Message Detector.
Verifies phishing, prize scams, false-positive resistance, and edge cases.
"""

import pytest
from detectors.message_detector import MessageDetector, analyze_message


@pytest.fixture
def detector():
    return MessageDetector()


def test_suspicious_example_a_bank_blocking(detector):
    """
    Suspicious Example A from specifications:
    'URGENT! Your bank account will be blocked today. Verify immediately at http://bank-verify-example.invalid and send your OTP to restore access.'
    Must be classified as HIGH risk (> 59).
    """
    text = (
        "URGENT! Your bank account will be blocked today. "
        "Verify immediately at http://bank-verify-example.invalid and send your OTP to restore access."
    )
    result = detector.analyze(text)

    assert result["category"] == "HIGH"
    assert result["score"] >= 60
    assert result["is_advisory"] is False

    indicator_names = [ind["name"] for ind in result["indicators"]]
    assert any("Urgency" in name for name in indicator_names)
    assert any("Suspension" in name for name in indicator_names)
    assert any("OTP" in name or "Credential" in name for name in indicator_names)
    assert any("Link" in name for name in indicator_names)
    assert len(result["recommendations"]) > 0


def test_suspicious_example_b_prize_payment(detector):
    """
    Suspicious Example B from specifications:
    'Congratulations! You won a ₹50,000 reward. Pay ₹999 processing charges to claim your prize.'
    Must be classified as HIGH risk.
    """
    text = "Congratulations! You won a ₹50,000 reward. Pay ₹999 processing charges to claim your prize."
    result = detector.analyze(text)

    assert result["category"] == "HIGH"
    assert result["score"] >= 60

    indicator_names = [ind["name"] for ind in result["indicators"]]
    assert any("Prize" in name or "Reward" in name for name in indicator_names)
    assert any("Fee" in name or "Charge" in name for name in indicator_names)


def test_legitimate_appointment_low_risk(detector):
    """
    Legitimate Example from specifications:
    'Your appointment is confirmed for tomorrow at 10:30 AM. Please arrive 10 minutes early.'
    Must be classified as LOW risk (<= 29).
    """
    text = "Your appointment is confirmed for tomorrow at 10:30 AM. Please arrive 10 minutes early."
    result = detector.analyze(text)

    assert result["category"] == "LOW"
    assert result["score"] <= 29
    assert result["score"] == 0 or len(result["indicators"]) == 0


def test_legitimate_security_advisory_not_flagged(detector):
    """
    Legitimate Security Example from specifications:
    'Your bank will never ask you to share your OTP or PIN. Contact customer support using the official number if you need help.'
    Must NOT be classified as high risk or phishing despite containing words 'bank', 'OTP', and 'PIN'.
    """
    text = (
        "Your bank will never ask you to share your OTP or PIN. "
        "Contact customer support using the official number if you need help."
    )
    result = detector.analyze(text)

    assert result["category"] == "LOW"
    assert result["score"] <= 29
    assert result["is_advisory"] is True
    # The advisory must be explicitly recognized in the explanation
    assert "advisory" in result["explanation"].lower() or "awareness" in result["explanation"].lower()


def test_job_offer_scam(detector):
    """Verify task / investment scams with guaranteed daily returns."""
    text = "Work from home! Earn ₹5,000 daily by liking videos on Telegram. Pay registration fee of ₹500 to join."
    result = detector.analyze(text)

    assert result["category"] in ("MEDIUM", "HIGH")
    assert result["score"] >= 40
    indicator_names = [ind["name"] for ind in result["indicators"]]
    assert any("Job" in name or "Investment" in name for name in indicator_names)


def test_empty_and_whitespace_input(detector):
    """Empty and whitespace strings should return safe default response."""
    empty_res = detector.analyze("")
    assert empty_res["category"] == "LOW"
    assert empty_res["score"] == 0

    space_res = detector.analyze("    \n\t   ")
    assert space_res["category"] == "LOW"
    assert space_res["score"] == 0


def test_excessively_long_input(detector):
    """Excessively long inputs (> 5000 chars) must be truncated gracefully without crashing."""
    huge_text = "Check this appointment note. " * 300
    assert len(huge_text) > 5000
    res = detector.analyze(huge_text)
    assert res is not None
    assert "score" in res
    assert res["score"] <= 29


def test_xss_injection_in_message(detector):
    """Verify that XSS script payloads in message are properly HTML escaped in highlights."""
    payload = "<script>alert('pwned')</script> URGENT verify at http://test.invalid"
    res = detector.analyze(payload)
    # The output HTML should NOT contain unescaped <script> tags
    assert "<script>" not in res["highlights_html"]
    assert "&lt;script&gt;" in res["highlights_html"]


def test_singleton_convenience_function():
    """Verify analyze_message shortcut returns identical structure."""
    res = analyze_message("Your appointment is confirmed for tomorrow.")
    assert "score" in res
    assert "category" in res
    assert "indicators" in res
