"""
Automated unit tests for ThreatIntelDB (MongoDB + In-Memory Fallback).
Verifies that database telemetry operates safely, records sanitized data,
never stores private text, and functions seamlessly even when MongoDB is offline.
"""

import pytest
from database import ThreatIntelDB


@pytest.fixture
def test_db():
    # Create an isolated database instance
    db = ThreatIntelDB(mongo_uri="mongodb://non-existent-host:27017/scamsathi_test")
    return db


def test_in_memory_fallback_active_when_mongo_unreachable(test_db):
    """If MongoDB server is unreachable, DB must seamlessly fall back to memory buffer without crashing."""
    assert test_db.is_connected is False
    stats = test_db.get_threat_stats()
    assert "In-Memory" in stats["storage_mode"]
    assert stats["is_mongo_connected"] is False


def test_threat_recording_sanitized_privacy_guarantee(test_db):
    """
    CRITICAL PRIVACY TEST:
    Verify that recorded threats do NOT contain full message text or personal data.
    """
    record = test_db.record_threat(
        threat_type="phishing_message",
        category="HIGH",
        score=90,
        indicators=["Urgency", "OTP Harvesting"],
        domain="sbi-fake.invalid",
        target_brand="State Bank of India",
        summary="Urgent bank suspension scam.",
    )

    assert record["threat_type"] == "phishing_message"
    assert record["category"] == "HIGH"
    assert record["score"] == 90
    assert record["domain"] == "sbi-fake.invalid"
    assert "Urgency" in record["threat_indicators"]
    # Ensure no phone numbers or personal keys exist
    assert "user_message" not in record
    assert "phone" not in record
    assert "user_id" not in record


def test_get_recent_threats_and_stats(test_db):
    """Verify stats aggregation and retrieval of recent items."""
    test_db.clear_memory()
    test_db.record_threat(
        threat_type="suspicious_url",
        category="HIGH",
        score=85,
        indicators=["Brand Spoofing"],
        domain="fake-bank.invalid",
    )
    test_db.record_threat(
        threat_type="phishing_message",
        category="MEDIUM",
        score=50,
        indicators=["Manufactured Urgency"],
    )

    recent = test_db.get_recent_threats(limit=5)
    assert len(recent) == 2
    assert recent[0]["threat_type"] == "phishing_message"  # Most recent first

    stats = test_db.get_threat_stats()
    assert stats["total_analyzed"] == 2
    assert stats["high_risk_count"] == 1
    assert stats["medium_risk_count"] == 1
