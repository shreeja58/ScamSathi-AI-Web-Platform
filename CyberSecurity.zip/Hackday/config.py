"""
ScamSathi AI - Configuration Module
"""

import os
import secrets


class Config:
    """Base application configuration."""

    # Application Metadata
    APP_NAME = "ScamSathi AI"
    APP_TAGLINE = "Detect the Scam. Expose the Trap. Protect Your Privacy."
    VERSION = "1.0.0"

    # Security & Sessions
    SECRET_KEY = os.environ.get("SCAMSATHI_SECRET_KEY", secrets.token_hex(32))
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    MAX_CONTENT_LENGTH = 1 * 1024 * 1024  # 1 MB maximum request payload

    # Debug mode disabled by default
    DEBUG = os.environ.get("FLASK_DEBUG", "0").lower() in ("1", "true", "yes")

    # Anti-CSRF Token Secret
    CSRF_SECRET = os.environ.get("SCAMSATHI_CSRF_SECRET", secrets.token_hex(32))

    # MongoDB Threat Intelligence URI (Optional with in-memory fallback)
    MONGO_URI = os.environ.get("MONGO_URI", "mongodb://localhost:27017/scamsathi")


class ProductionConfig(Config):
    """Production configuration."""

    DEBUG = False
    SESSION_COOKIE_SECURE = True


class DevelopmentConfig(Config):
    """Development configuration."""

    DEBUG = True


class TestingConfig(Config):
    """Testing configuration."""

    TESTING = True
    DEBUG = False
    SECRET_KEY = "test-secret-key-for-scamsathi-automated-tests"
    CSRF_SECRET = "test-csrf-secret"
