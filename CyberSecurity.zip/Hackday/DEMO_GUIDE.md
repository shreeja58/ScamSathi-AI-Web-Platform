# ScamSathi AI — Hackathon Presentation & Demo Guide

> **Tagline:** Detect the Scam. Expose the Trap. Protect Your Privacy.  
> **Target Audience:** Hackathon Judges, Evaluators, Mentors, and General Users.  
> **Duration:** Exactly 3 Minutes (180 Seconds).

---

## 🕒 3-Minute Presentation Plan (Timed Script)

### ⏱️ 0:00–0:30 — Introduce the Problem & Target Users
* **Speaker Script:**  
  *"Good morning judges. In India today, over ₹7,000 Crores was drained from ordinary citizens through digital financial fraud in recent years. Phishers prey on panic—sending fake courier alerts, electricity cutoff threats, and bogus KYC links on WhatsApp and SMS. When ordinary users encounter these messages, they have nowhere safe to turn: existing cybersecurity tools are either enterprise black-boxes or demand that users upload their private chats to corporate cloud APIs.*  
  *We built **ScamSathi AI**—an explainable, 100% privacy-first cybersecurity platform that detects scams, exposes deceptive URLs safely offline, and educates citizens against emerging camera-permission traps."*
* **On-Screen Action:**  
  Show the ScamSathi AI landing dashboard at `http://127.0.0.1:5000/`. Highlight the tagline and the 3 distinct defense modules.

---

### ⏱️ 0:30–1:10 — Live Demo: AI Phishing Message Detector
* **Speaker Script:**  
  *"Let's see our first module: the Phishing Message Detector. Scammers don't just use bad grammar anymore—they weaponize manufactured urgency and credential theft.*  
  *First, I'll load **Suspicious Scenario A**: a message claiming our bank account will be blocked today and asking for an immediate OTP. In one click, ScamSathi's contextual heuristic engine flags this as **HIGH RISK (90/100)**.*  
  *Notice our UI doesn't just give an opaque number. It highlights the exact threat indicators in the text, explains the psychological urgency trigger, and provides tailored defense steps.*  
  *Now, watch how we prevent false positives. I'll load an official bank advisory: 'Your bank will never ask you to share your OTP or PIN'. Even though it contains the words 'bank' and 'OTP', our context-aware negation engine recognizes this as an advisory and scores it in the **LOW RISK** green band. That's real contextual awareness, not naive keyword matching."*
* **On-Screen Action:**  
  1. Click **Message Detector** in nav.  
  2. Select `🚨 Suspicious A: Bank Blocking & OTP Demand` and click **Analyze Message**. Point to the highlighted words, gauge bar, and breakdown.  
  3. Select `🛡️ Legitimate Security: Official Bank Anti-Scam Advisory` and click **Analyze Message**. Show the Low Risk score and the advisory badge.

---

### ⏱️ 1:10–1:40 — Live Demo: Suspicious URL Analyzer (100% Offline)
* **Speaker Script:**  
  *"Next is our Suspicious URL Analyzer. Opening unknown links is like stepping onto an uninspected minefield. ScamSathi AI inspects web addresses **100% offline without sending a single network packet or DNS query** to the destination.*  
  *Let's test `http://sbi-account-verify.invalid/update-kyc`. Immediately, our analyzer identifies that this domain is impersonating the State Bank of India brand on an unverified domain.*  
  *We also check for raw IP hostnames, hidden URL shorteners, and deceptive user-info tricks like `google.com@attacker-portal.invalid`.*  
  *Crucially, we bust the most common myth among users: that an HTTPS padlock means a website is safe. Our reality check callout explains that phishers use free SSL certificates too."*
* **On-Screen Action:**  
  1. Navigate to **URL Analyzer**.  
  2. Select `🚨 Brand Spoofing` and click **Analyze URL**.  
  3. Point out the parsed URL anatomy table, the brand spoofing indicator, and the *HTTPS Reality Check* card.

---

### ⏱️ 1:40–2:15 — Live Demo: Camera-Phishing Awareness Simulator
* **Speaker Script:**  
  *"Our third module tackles an emerging, dangerous attack vector: **Camera-Permission Phishing**.*  
  *Criminals now send fake delivery failure alerts that lure victims to web portals claiming 'facial verification is needed to release your parcel'. Once granted, they capture facial biometrics for deepfakes or extortion.*  
  *We built a safe educational simulator. Notice our mandatory banner: **CYBERSECURITY TRAINING SIMULATION — NO REAL CAMERA ACCESS**.*  
  *The user is walked through the lure, then lands on a simulated courier portal with a custom HTML/CSS permission prompt. If the user simulates 'Allow', we reveal how facial biometrics are stolen. If they simulate 'Deny', we reinforce that no legitimate delivery courier ever requires your webcam. This provides hands-on inoculation against social engineering without touching user hardware."*
* **On-Screen Action:**  
  1. Navigate to **Camera Simulator**.  
  2. Walk through Screen 1 (The Lure) $\rightarrow$ click **Simulate Clicking Link**.  
  3. Show the mock browser and click **Simulate Deny** (or **Simulate Allow**).  
  4. Show Screen 3 (Educational Explanation) and Screen 4 (Defense Checklist).

---

### ⏱️ 2:15–2:40 — Tech Stack & Privacy-First Architecture
* **Speaker Script:**  
  *"Under the hood, ScamSathi AI is built on Python Flask, vanilla ES6, and responsive CSS. We deliberately designed the system to run locally in-memory.*  
  *There is zero database logging, zero telemetry, and zero transmission of personal chats to third-party APIs. We implemented CSRF tokens, strict Content Security Policy, and XSS sanitization.*  
  *Our automated test suite runs 29 comprehensive pytest cases in under 1 second, confirming that legitimate messages aren't falsely flagged and that zero network requests are made during URL analysis."*
* **On-Screen Action:**  
  Point to the bottom banner: `100% Local Heuristics • Zero Sensitive Data Saved • Python Flask • 29 Tests Passed`.

---

### ⏱️ 2:40–3:00 — Social Impact & Future Vision
* **Speaker Script:**  
  *"ScamSathi AI bridges the digital divide in India. By providing clear explanations rather than black-box scores, it turns vulnerable citizens into informed digital defenders.*  
  *Our roadmap includes lightweight on-device multilingual NLP for regional Indic languages—Hindi, Tamil, Bengali—and packaging our offline URL engine into a lightweight browser extension.*  
  *ScamSathi AI: Detect the Scam. Expose the Trap. Protect Your Privacy. Thank you, and we welcome your questions!"*

---

## 🎯 Top 10 Hackathon Judge Questions & Concise Answers

### Q1: How does your risk score work?
**Answer:**  
*"Our scoring engine uses transparent, additive weights based on verified cyber threat indicators. High-severity traits like OTP harvesting or advance fee demands add 30–35 points; secondary traits like urgency or brand mentions add 10–15 points. Synergistic combinations—such as an urgent suspension threat combined with a verification link—receive a composite risk bonus. Scores are capped between 0 and 100 and mapped into three documented bands: Low (0–29), Medium (30–59), and High (60–100)."*

---

### Q2: Is this a machine-learning model or a rule-based system?
**Answer:**  
*"For this core release, we intentionally prioritized a high-precision, explainable rule-based heuristic engine over a black-box ML model. In cybersecurity awareness, explainability is essential: users need to see the exact pattern—like an advance-fee trap or typosquatted domain—to learn. Heuristics are 100% predictable, lightning-fast (<5ms), require zero GPU hardware, and work completely offline without privacy leakage. We designed our architecture so a lightweight local NLP classifier (e.g. an ONNX transformer) can plug in as an optional secondary layer."*

---

### Q3: How do you avoid false positives on legitimate messages?
**Answer:**  
*"We implemented context-aware negation rules rather than simple keyword counting. For instance, if a message contains security warning phrases like 'will never ask you to share your OTP or PIN' alongside an official support number, our advisory filter recognizes the context, suppresses the credential-theft penalty, and classifies it as Low Risk. Similarly, routine appointment confirmations with times and dates score zero because they lack coercive threats or credential demands."*

---

### Q4: Can an attacker bypass your detector?
**Answer:**  
*"Like any heuristic or AI defense, an adversary who crafts completely novel phrasing or avoids known trigger words could achieve a lower score. That is precisely why ScamSathi AI includes prominent educational disclaimers explaining that risk scores are indicative heuristics, not guarantees of safety. We empower users with foundational mental models—such as never sharing OTPs regardless of score and verifying domains in the address bar."*

---

### Q5: How do you analyze URLs without opening them?
**Answer:**  
*"We rely on structural syntactic analysis using Python's `urllib.parse` and `ipaddress` modules. We inspect the protocol scheme, verify if the host is a raw IP address or obfuscated hex IP, check for deceptive user-info syntax (the `@` symbol), match known link-shortening hosts, and perform typosquatting distance checks against known bank brands. Because we never make HTTP requests or DNS queries, the user's IP address is never exposed to the attacker's server."*

---

### Q6: How is user privacy protected?
**Answer:**  
*"ScamSathi AI adheres to strict data minimization. Analysis is performed entirely in volatile server memory. We deliberately omitted a persistent database: messages and URLs are never saved to disk, never logged in access logs, and never transmitted to external cloud APIs or LLM providers. Once the HTTP response is rendered, the analyzed text is discarded from RAM."*

---

### Q7: Does the camera simulator actually activate the camera?
**Answer:**  
*"Absolutely not. The simulator is built 100% in pure HTML and CSS with a client-side JavaScript state machine. The browser permission pop-up is an HTML mockup designed to look like a browser dialog. We have an automated test (`test_strict_no_real_camera_api_in_codebase`) that asserts neither `getUserMedia` nor `navigator.mediaDevices` exists anywhere in the codebase."*

---

### Q8: What makes ScamSathi AI unique compared to existing tools?
**Answer:**  
*"Existing tools either classify a URL as safe/unsafe with zero explanation, or require enterprise IT agents. ScamSathi AI is built specifically for everyday citizens in India facing WhatsApp, SMS, and courier scams. It is uniquely explainable—highlighting matched suspicious phrases in text—operates 100% offline for privacy, and includes the first interactive educational simulator for camera-permission phishing."*

---

### Q9: How would you scale the system for millions of users?
**Answer:**  
*"Because each analysis is stateless, offline, and computationally lightweight (<5ms CPU time without heavy neural network inference), a single standard cloud container (such as a 2 vCPU Gunicorn instance behind Nginx) can handle thousands of concurrent requests per second. It can be easily packaged as a progressive web app (PWA) or client-side browser extension where the heuristics run entirely within the user's browser without requiring backend servers at all."*

---

### Q10: What would you improve with more time?
**Answer:**  
*"Three key features: First, integrating a tiny on-device ONNX model for regional Indian languages (Hindi, Tamil, Telugu, Marathi). Second, adding local client-side OCR (via Tesseract.js) so senior citizens can simply take a screenshot of a suspicious WhatsApp message without typing. Third, releasing a Chrome/Firefox extension that automatically intercepts suspicious delivery links in the background."*
