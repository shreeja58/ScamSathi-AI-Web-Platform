/**
 * ScamSathi AI — Interactive Client-Side Logic
 * - Mobile Navigation
 * - Sample Scenario Preloaders
 * - FAQ Accordions
 * - Camera Phishing Educational Sandbox (Pure DOM state machine - zero camera hardware)
 */

document.addEventListener("DOMContentLoaded", function () {
    initNavigation();
    initFaqAccordion();
    initMessageDetector();
    initUrlAnalyzer();
    initCameraSimulator();
});

/* -------------------------------------------------------------
 * 1. Mobile Navigation
 * ------------------------------------------------------------- */
function initNavigation() {
    const navToggle = document.getElementById("navToggle");
    const navMenu = document.getElementById("navMenu");

    if (navToggle && navMenu) {
        navToggle.addEventListener("click", function () {
            navMenu.classList.toggle("open");
        });
    }
}

/* -------------------------------------------------------------
 * 2. FAQ Accordion
 * ------------------------------------------------------------- */
function initFaqAccordion() {
    const headers = document.querySelectorAll(".accordion-header");
    headers.forEach(header => {
        header.addEventListener("click", function () {
            const item = this.parentElement;
            const isOpen = item.classList.contains("open");

            // Close siblings
            document.querySelectorAll(".accordion-item").forEach(i => i.classList.remove("open"));

            if (!isOpen) {
                item.classList.add("open");
            }
        });
    });
}

/* -------------------------------------------------------------
 * 3. Message Detector Sample Preloader & Logic
 * ------------------------------------------------------------- */
const MESSAGE_SCENARIOS = {
    suspicious_a: "URGENT! Your bank account will be blocked today. Verify immediately at http://bank-verify-example.invalid and send your OTP to restore access.",
    suspicious_b: "Congratulations! You won a ₹50,000 reward. Pay ₹999 processing charges to claim your prize.",
    suspicious_electricity: "Dear customer, your electricity power will be disconnected tonight at 9:30 PM because your previous month bill was not updated. Please immediately contact electricity officer at 9876543210.",
    suspicious_job: "Congratulations! Earn ₹5,000 daily from home by liking YouTube videos. Work from home no experience required. Pay refundable deposit of ₹1,500 to activate VIP task account.",
    legit_appointment: "Your appointment is confirmed for tomorrow at 10:30 AM. Please arrive 10 minutes early.",
    legit_security: "Your bank will never ask you to share your OTP or PIN. Contact customer support using the official number if you need help."
};

function initMessageDetector() {
    const textarea = document.getElementById("messageInput");
    const charCount = document.getElementById("charCount");
    const sampleSelector = document.getElementById("sampleSelector");
    const clearBtn = document.getElementById("clearBtn");

    if (!textarea) return;

    // Update char counter
    function updateCounter() {
        if (charCount) {
            charCount.textContent = textarea.value.length;
        }
    }
    textarea.addEventListener("input", updateCounter);
    updateCounter();

    // Dropdown sample selector
    if (sampleSelector) {
        sampleSelector.addEventListener("change", function () {
            const key = this.value;
            if (key && MESSAGE_SCENARIOS[key]) {
                textarea.value = MESSAGE_SCENARIOS[key];
                updateCounter();
            }
        });
    }

    // Quick scenario chips
    document.querySelectorAll("[data-scenario]").forEach(chip => {
        chip.addEventListener("click", function () {
            const key = this.getAttribute("data-scenario");
            if (key && MESSAGE_SCENARIOS[key]) {
                textarea.value = MESSAGE_SCENARIOS[key];
                updateCounter();
                if (sampleSelector) sampleSelector.value = key;
                // Scroll up to form on mobile
                textarea.scrollIntoView({ behavior: "smooth", block: "center" });
            }
        });
    });

    // Clear button
    if (clearBtn) {
        clearBtn.addEventListener("click", function () {
            textarea.value = "";
            if (sampleSelector) sampleSelector.value = "";
            updateCounter();
            textarea.focus();
        });
    }
}

/* -------------------------------------------------------------
 * 4. URL Analyzer Sample Preloader & Logic
 * ------------------------------------------------------------- */
const URL_SCENARIOS = {
    brand_spoof: "http://sbi-account-verify.invalid/update-kyc",
    raw_ip: "http://185.220.101.5/banking/login.php",
    userinfo: "http://google.com@attacker-portal.invalid/signin",
    shortener: "https://bit.ly/claim-cashback-reward",
    excessive_subdomain: "http://verify.account.security.service.tracker.top/auth",
    clean_gov: "https://cybercrime.gov.in",
    clean_bank: "https://onlinesbi.sbi"
};

function initUrlAnalyzer() {
    const input = document.getElementById("urlInput");
    const selector = document.getElementById("urlSampleSelector");
    const clearBtn = document.getElementById("clearUrlBtn");

    if (!input) return;

    // Dropdown sample selector
    if (selector) {
        selector.addEventListener("change", function () {
            const key = this.value;
            if (key && URL_SCENARIOS[key]) {
                input.value = URL_SCENARIOS[key];
            }
        });
    }

    // Quick scenario chips
    document.querySelectorAll("[data-url-scenario]").forEach(chip => {
        chip.addEventListener("click", function () {
            const key = this.getAttribute("data-url-scenario");
            if (key && URL_SCENARIOS[key]) {
                input.value = URL_SCENARIOS[key];
                if (selector) selector.value = key;
                input.scrollIntoView({ behavior: "smooth", block: "center" });
            }
        });
    });

    // Clear button
    if (clearBtn) {
        clearBtn.addEventListener("click", function () {
            input.value = "";
            if (selector) selector.value = "";
            input.focus();
        });
    }
}

/* -------------------------------------------------------------
 * 5. Camera Phishing Awareness Simulator (Educational Sandbox)
 * Strict Requirement: ZERO real camera access, ZERO webcam APIs.
 * Pure DOM state machine.
 * ------------------------------------------------------------- */
function initCameraSimulator() {
    const container = document.getElementById("simulatorContainer");
    if (!container) return;

    // Step elements
    const screens = {
        1: document.getElementById("screen1"),
        2: document.getElementById("screen2"),
        3: document.getElementById("screen3"),
        4: document.getElementById("screen4")
    };

    const indicators = {
        1: document.getElementById("stepIndicator1"),
        2: document.getElementById("stepIndicator2"),
        3: document.getElementById("stepIndicator3"),
        4: document.getElementById("stepIndicator4")
    };

    const lines = {
        1: document.getElementById("stepLine1"),
        2: document.getElementById("stepLine2"),
        3: document.getElementById("stepLine3")
    };

    // Buttons
    const btnGoToScreen2 = document.getElementById("btnGoToScreen2");
    const btnSimAllow = document.getElementById("btnSimAllow");
    const btnSimDeny = document.getElementById("btnSimDeny");
    const btnGoToScreen4 = document.getElementById("btnGoToScreen4");
    const btnRestart = document.getElementById("btnRestartSimulator");

    // Outcome display sections in Screen 3
    const outcomeAllow = document.getElementById("outcomeAllow");
    const outcomeDeny = document.getElementById("outcomeDeny");

    function goToStep(stepNum) {
        // Toggle screens
        Object.keys(screens).forEach(k => {
            if (screens[k]) {
                screens[k].classList.toggle("active", parseInt(k) === stepNum);
            }
        });

        // Toggle stepper indicators
        for (let i = 1; i <= 4; i++) {
            if (indicators[i]) {
                indicators[i].classList.toggle("active", i <= stepNum);
            }
            if (lines[i] && i < 4) {
                lines[i].classList.toggle("active", i < stepNum);
            }
        }

        // Smooth scroll to container top
        container.scrollIntoView({ behavior: "smooth", block: "start" });
    }

    // Step 1 -> Step 2
    if (btnGoToScreen2) {
        btnGoToScreen2.addEventListener("click", function () {
            goToStep(2);
        });
    }

    // Step 2 Simulated Actions:
    // Pure DOM events; no hardware camera calls!
    if (btnSimAllow) {
        btnSimAllow.addEventListener("click", function () {
            if (outcomeAllow) outcomeAllow.style.display = "block";
            if (outcomeDeny) outcomeDeny.style.display = "none";
            goToStep(3);
        });
    }

    if (btnSimDeny) {
        btnSimDeny.addEventListener("click", function () {
            if (outcomeAllow) outcomeAllow.style.display = "none";
            if (outcomeDeny) outcomeDeny.style.display = "block";
            goToStep(3);
        });
    }

    // Step 3 -> Step 4
    if (btnGoToScreen4) {
        btnGoToScreen4.addEventListener("click", function () {
            goToStep(4);
        });
    }

    // Restart Simulator
    if (btnRestart) {
        btnRestart.addEventListener("click", function () {
            if (outcomeAllow) outcomeAllow.style.display = "none";
            if (outcomeDeny) outcomeDeny.style.display = "none";
            goToStep(1);
        });
    }

    console.info("ScamSathi Simulator: Running pure educational sandbox. Zero hardware APIs loaded.");
}
