"""
Generate ANIMATED_VIDEO_SCRIPT_AND_STORYBOARD.docx
Contains the complete 2.5-minute video production script, visual animations,
sound design, and spoken voiceover in simple English for hackathon presentations.
"""

import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls


def set_cell_background(cell, fill_hex):
    tcPr = cell._element.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)


def generate_video_docx():
    doc = docx.Document()

    for s in doc.sections:
        s.top_margin = Inches(0.8)
        s.bottom_margin = Inches(0.8)
        s.left_margin = Inches(0.8)
        s.right_margin = Inches(0.8)

    C_NAVY = RGBColor(11, 15, 25)
    C_CYAN = RGBColor(6, 182, 212)
    C_TEAL = RGBColor(20, 184, 166)
    C_GRAY = RGBColor(100, 116, 139)

    # Title
    p_badge = doc.add_paragraph()
    r_b = p_badge.add_run("VIDEO PRODUCTION & ANIMATED STORYBOARD GUIDE • 2.5 MINUTES")
    r_b.font.bold = True
    r_b.font.size = Pt(9.5)
    r_b.font.color.rgb = C_CYAN

    p_title = doc.add_paragraph()
    r_t = p_title.add_run("ScamSathi AI — Animated Explainer Video Script")
    r_t.font.bold = True
    r_t.font.size = Pt(22)
    r_t.font.color.rgb = C_NAVY

    p_sub = doc.add_paragraph()
    r_s = p_sub.add_run("Scene-by-scene visual animation cues, sound effects, on-screen text, and simple English voiceover narration.")
    r_s.font.size = Pt(11)
    r_s.font.italic = True
    r_s.font.color.rgb = C_GRAY

    doc.add_paragraph().paragraph_format.space_after = Pt(12)

    scenes = [
        {
            "num": "SCENE 1 (0:00 – 0:30)",
            "title": "The Digital Trap in India (The Crisis)",
            "visual": "A 2D animated Indian citizen (Ramesh, 35) is sitting on a sofa scrolling on his smartphone. A loud message alert chime rings. An SMS bubble pops up on screen with a flashing red warning outline: 'URGENT! Power disconnected tonight at 9:30 PM due to unpaid bill. Pay immediately: http://pay-power-update.invalid'. A ticking clock appears in the background with a 2-hour deadline.",
            "sfx": "WhatsApp alert sound, fast ticking clock, subtle suspense background music.",
            "on_screen_text": "THE PROBLEM: Manufactured Panic • ₹7,000+ Crores Lost in India",
            "voiceover": "\"Meet Ramesh. Like millions of everyday citizens across India, he receives a terrifying message claiming his home's electricity will be cut off tonight in just two hours. Scammers manufacture panic so victims rush to click links and make payments before verifying the facts.\""
        },
        {
            "num": "SCENE 2 (0:30 – 1:00)",
            "title": "Module 1 — AI Phishing Message Detector in Action",
            "visual": "Ramesh pauses and takes a deep breath. He opens ScamSathi AI on his phone. He pastes the SMS into the text box. A glowing cyan laser scanning beam sweeps up and down the text. Red bounding boxes highlight 'will be disconnected' and 'immediately to restore'. A sleek gauge meter animates upward, landing on 85 (HIGH RISK). A green checkmark shield pops up with the verdict: 'SCAM DETECTED • DO NOT PAY'.",
            "sfx": "Futuristic laser scan sound, digital calculation chime, satisfying success chime.",
            "on_screen_text": "EXPLAINABLE HEURISTICS • Sub-5ms Analysis • False-Positive Protection",
            "voiceover": "\"Instead of clicking the link, Ramesh opens ScamSathi AI. In milliseconds, our explainable heuristic engine scans the text, highlights the psychological urgency trick, and reveals the threat of disconnection. It calculates an 85 out of 100 high-risk score and advises: DO NOT PAY. Ramesh saves his hard-earned money.\""
        },
        {
            "num": "SCENE 3 (1:00 – 1:30)",
            "title": "Module 2 — 100% Offline Suspicious URL Analyzer",
            "visual": "The camera zooms into the web link: 'http://sbi-verification-portal.invalid'. A digital magnifying glass deconstructs the URL into Scheme, Host, and Path. An animated cyber firewall blocks any outbound connection. A padlock icon with an 'X' appears, displaying the educational tip: 'HTTPS != Safe'. An alert badge reveals: 'Brand Impersonation of State Bank of India'.",
            "sfx": "Whoosh transition, digital typing click, security shield snap sound.",
            "on_screen_text": "ZERO-NETWORK INSPECTION • Never Pings Remote Hosts • 100% Safe",
            "voiceover": "\"What about the suspicious link? Ordinary scanners make the mistake of pinging remote links, exposing your IP address to hackers. ScamSathi inspects URLs 100 percent offline using string parsing. It exposes brand spoofing and deceptive links without ever sending a single network packet to the scammer's server.\""
        },
        {
            "num": "SCENE 4 (1:30 – 2:00)",
            "title": "Module 3 — Camera-Phishing Awareness Sandbox",
            "visual": "Ramesh receives another alert: a fake parcel delivery message claiming: 'Delivery incomplete! Open link to scan face.' When clicked, a mock browser permission prompt appears: 'track-delivery.invalid wants to use your camera'. A shadow hacker silhouette is shown in the background trying to capture face video. An animated alert shows how stolen face scans create AI deepfakes. A cursor clicks 'Simulate Deny', locking out the hacker.",
            "sfx": "Camera shutter click sound, warning buzzer, digital lock click.",
            "on_screen_text": "CYBERSECURITY SANDBOX • Zero Webcam Access • Deepfake Defense",
            "voiceover": "\"Even worse, new parcel scams trick users into granting browser camera permissions to 'verify delivery'. ScamSathi includes India's first interactive camera phishing sandbox. It safely shows users how attackers steal facial video for AI deepfakes and extortion—all simulated in pure HTML and CSS with zero webcam hardware access.\""
        },
        {
            "num": "SCENE 5 (2:00 – 2:30)",
            "title": "Privacy First, MongoDB Radar & National Impact",
            "visual": "The ScamSathi AI Shield expands to full screen, pulsing with electric cyan light. Anonymous threat signals flow into a live Community Threat Radar map of India powered by MongoDB. A prominent banner displays India's National Cyber Crime Helpline: 1930 and cybercrime.gov.in. Ramesh smiles with confidence, holding his smartphone securely.",
            "sfx": "Uplifting, victorious corporate tech music crescendo.",
            "on_screen_text": "SCAMSATHI AI • 100% In-Memory Privacy • National Helpline: 1930",
            "voiceover": "\"Best of all, ScamSathi AI stores zero personal messages. All analysis runs locally in temporary memory, protecting citizen privacy while crowdsourcing threat trends to India's 1930 cyber helpline. ScamSathi AI: Detect the Scam. Expose the Trap. Protect Your Privacy. Built to protect 800 million citizens!\""
        }
    ]

    for sc in scenes:
        p_h = doc.add_paragraph()
        p_h.paragraph_format.space_before = Pt(14)
        p_h.paragraph_format.space_after = Pt(2)
        r_h = p_h.add_run(f"🎬 {sc['num']} — {sc['title']}")
        r_h.font.bold = True
        r_h.font.size = Pt(13)
        r_h.font.color.rgb = C_CYAN

        t = doc.add_table(rows=4, cols=2)
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.rows[0].cells[0].text = "Visual Animation:"
        t.rows[0].cells[1].text = sc["visual"]
        t.rows[1].cells[0].text = "SFX & Music:"
        t.rows[1].cells[1].text = sc["sfx"]
        t.rows[2].cells[0].text = "On-Screen Text:"
        t.rows[2].cells[1].text = sc["on_screen_text"]
        t.rows[3].cells[0].text = "Voiceover (Script):"
        t.rows[3].cells[1].text = sc["voiceover"]

        for row in t.rows:
            set_cell_background(row.cells[0], "F8FAFC")
            set_cell_background(row.cells[1], "F1F5F9")
            for c in row.cells:
                p = c.paragraphs[0]
                p.runs[0].font.name = "Arial"
                p.runs[0].font.size = Pt(9)
                p.runs[0].font.color.rgb = C_NAVY

    out_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "ANIMATED_VIDEO_SCRIPT_AND_STORYBOARD.docx")
    doc.save(out_file)
    print(f"Video production script saved to: {out_file}")


if __name__ == "__main__":
    generate_video_docx()
