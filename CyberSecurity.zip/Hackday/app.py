"""
ScamSathi AI - Web Application
Main Flask entry point providing dashboard routes, detection endpoints,
and the camera-phishing training simulator.
"""

import hashlib
import hmac
import os
import uuid
from typing import Optional
from flask import (
    Flask,
    Response,
    abort,
    jsonify,
    render_template,
    request,
    session,
)

from config import Config
from database import db_instance
from detectors.message_detector import analyze_message
from detectors.url_analyzer import analyze_url


def create_app(config_class=Config) -> Flask:
    """Application factory for ScamSathi AI."""
    app = Flask(__name__)
    app.config.from_object(config_class)

    # ---------------------------------------------------------
    # CSRF Token Helpers & Template Context
    # ---------------------------------------------------------
    def get_or_create_csrf_token() -> str:
        """Generate a cryptographically tied session CSRF token."""
        if "session_token" not in session:
            session["session_token"] = str(uuid.uuid4())
        secret = app.config.get("CSRF_SECRET", "default-csrf-secret").encode("utf-8")
        token_src = session["session_token"].encode("utf-8")
        return hmac.new(secret, token_src, hashlib.sha256).hexdigest()

    @app.context_processor
    def inject_global_template_vars():
        """Expose CSRF token, metadata, and active path to templates."""
        return {
            "csrf_token": get_or_create_csrf_token(),
            "app_name": app.config.get("APP_NAME", "ScamSathi AI"),
            "app_tagline": app.config.get(
                "APP_TAGLINE", "Detect the Scam. Expose the Trap. Protect Your Privacy."
            ),
            "app_version": app.config.get("VERSION", "1.0.0"),
        }

    def verify_csrf():
        """Verify CSRF token on POST requests."""
        if app.config.get("TESTING", False):
            return  # Allow simplified test requests

        submitted_token = (
            request.form.get("csrf_token")
            or request.headers.get("X-CSRFToken")
            or (request.is_json and request.json.get("csrf_token"))
        )
        expected_token = get_or_create_csrf_token()
        if not submitted_token or not hmac.compare_digest(submitted_token, expected_token):
            abort(400, description="Invalid or missing security token (CSRF). Please refresh the page and try again.")

    # ---------------------------------------------------------
    # Security Response Headers
    # ---------------------------------------------------------
    @app.after_request
    def set_security_headers(response: Response) -> Response:
        """Attach defense-in-depth security headers."""
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["X-XSS-Protection"] = "1; mode=block"
        response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
        response.headers["Content-Security-Policy"] = (
            "default-src 'self'; "
            "style-src 'self' 'unsafe-inline'; "
            "script-src 'self' 'unsafe-inline'; "
            "img-src 'self' data:;"
        )
        return response

    # ---------------------------------------------------------
    # Core Application Routes
    # ---------------------------------------------------------
    @app.route("/")
    def index():
        """Main dashboard with threat intelligence radar."""
        stats = db_instance.get_threat_stats()
        recent_threats = db_instance.get_recent_threats(limit=5)
        return render_template(
            "index.html",
            stats=stats,
            recent_threats=recent_threats,
        )

    @app.route("/detect/message", methods=["GET", "POST"])
    def message_detector_view():
        """Phishing & scam message detection page."""
        result = None
        input_text = ""

        if request.method == "POST":
            verify_csrf()
            input_text = request.form.get("message", "")
            result = analyze_message(input_text)
            if result and result.get("category") in ("MEDIUM", "HIGH"):
                ind_names = [i["name"] for i in result.get("indicators", [])]
                db_instance.record_threat(
                    threat_type="phishing_message",
                    category=result["category"],
                    score=result["score"],
                    indicators=ind_names,
                    summary=result.get("explanation", "")[:120],
                )

        return render_template(
            "message_detector.html",
            result=result,
            input_text=input_text,
        )

    @app.route("/detect/url", methods=["GET", "POST"])
    def url_analyzer_view():
        """Suspicious URL analyzer page."""
        result = None
        input_url = ""

        if request.method == "POST":
            verify_csrf()
            input_url = request.form.get("url", "")
            result = analyze_url(input_url)
            if result and result.get("category") in ("MEDIUM", "HIGH"):
                ind_names = [i["name"] for i in result.get("risk_indicators", [])]
                db_instance.record_threat(
                    threat_type="suspicious_url",
                    category=result["category"],
                    score=result["score"],
                    indicators=ind_names,
                    domain=result.get("parsed", {}).get("hostname", ""),
                    summary=result.get("explanation", "")[:120],
                )

        return render_template(
            "url_analyzer.html",
            result=result,
            input_url=input_url,
        )

    @app.route("/simulator")
    def camera_simulator_view():
        """Camera-Phishing Awareness Simulator training module."""
        return render_template("camera_simulator.html")

    @app.route("/explainer")
    def animated_explainer_view():
        """Interactive animated visual video explainer."""
        return render_template("explainer.html")

    @app.route("/how-it-works")
    def how_it_works_view():
        """How ScamSathi AI works under the hood with real-time Indian case studies."""
        return render_template("how_it_works.html")


    # ---------------------------------------------------------
    # JSON APIs for Interactive Frontend / Threat Intelligence
    # ---------------------------------------------------------
    @app.route("/api/threat-intel", methods=["GET"])
    def api_threat_intel():
        """API endpoint for MongoDB anonymous community threat intelligence."""
        stats = db_instance.get_threat_stats()
        recent = db_instance.get_recent_threats(limit=10)
        return jsonify({
            "status": "success",
            "database": stats["storage_mode"],
            "is_mongo_connected": stats["is_mongo_connected"],
            "stats": stats,
            "recent_threats": recent,
        })

    @app.route("/api/analyze-message", methods=["POST"])
    def api_analyze_message():
        """JSON endpoint for message analysis."""
        verify_csrf()
        data = request.get_json(silent=True) or request.form
        text = data.get("message", "")
        if not text or not text.strip():
            return jsonify({"error": "Message content cannot be empty."}), 400
        analysis = analyze_message(text)
        if analysis and analysis.get("category") in ("MEDIUM", "HIGH"):
            ind_names = [i["name"] for i in analysis.get("indicators", [])]
            db_instance.record_threat(
                threat_type="phishing_message",
                category=analysis["category"],
                score=analysis["score"],
                indicators=ind_names,
                summary=analysis.get("explanation", "")[:120],
            )
        return jsonify(analysis)

    @app.route("/api/analyze-url", methods=["POST"])
    def api_analyze_url():
        """JSON endpoint for URL analysis."""
        verify_csrf()
        data = request.get_json(silent=True) or request.form
        url_input = data.get("url", "")
        if not url_input or not url_input.strip():
            return jsonify({"error": "URL parameter cannot be empty."}), 400
        analysis = analyze_url(url_input)
        if analysis and analysis.get("category") in ("MEDIUM", "HIGH"):
            ind_names = [i["name"] for i in analysis.get("risk_indicators", [])]
            db_instance.record_threat(
                threat_type="suspicious_url",
                category=analysis["category"],
                score=analysis["score"],
                indicators=ind_names,
                domain=analysis.get("parsed", {}).get("hostname", ""),
                summary=analysis.get("explanation", "")[:120],
            )
        return jsonify(analysis)

    # ---------------------------------------------------------
    # Error Handlers
    # ---------------------------------------------------------
    @app.errorhandler(400)
    def handle_bad_request(error):
        desc = getattr(error, "description", "Bad Request")
        if request.is_json or request.path.startswith("/api/"):
            return jsonify({"error": desc, "status": 400}), 400
        return render_template("error.html", code=400, message=desc), 400

    @app.errorhandler(404)
    def handle_not_found(error):
        if request.is_json or request.path.startswith("/api/"):
            return jsonify({"error": "Resource not found", "status": 404}), 404
        return render_template("error.html", code=404, message="The requested page could not be found."), 404

    @app.errorhandler(500)
    def handle_server_error(error):
        if request.is_json or request.path.startswith("/api/"):
            return jsonify({"error": "An internal server error occurred.", "status": 500}), 500
        return render_template(
            "error.html",
            code=500,
            message="An unexpected error occurred while processing your request. Please try again.",
        ), 500

    return app


app = create_app()

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 5000))
    # Listen on 0.0.0.0 so phones and other devices on the same network can access it
    app.run(host="0.0.0.0", port=port, debug=False)

