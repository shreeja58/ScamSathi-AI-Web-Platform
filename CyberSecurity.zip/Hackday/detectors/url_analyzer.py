"""
ScamSathi AI - Suspicious URL Analyzer
Performs 100% offline, string-based heuristic analysis of URLs.
NEVER connects to the network, visits submitted URLs, or resolves DNS.
"""

import ipaddress
import re
from typing import Any, Dict, List, Optional
from urllib.parse import urlparse, unquote


class URLAnalyzer:
    """Safe, explainable, offline URL heuristic analyzer."""

    # Risk thresholds
    THRESHOLD_LOW_MAX = 29
    THRESHOLD_MEDIUM_MAX = 59

    # Max input length
    MAX_URL_LENGTH = 2048

    # Recognizable URL Shorteners
    SHORTENERS = {
        "bit.ly",
        "tinyurl.com",
        "t.co",
        "is.gd",
        "buff.ly",
        "ow.ly",
        "cutt.ly",
        "rb.gy",
        "shorturl.at",
        "tiny.cc",
        "v.gd",
        "shorte.st",
        "bl.ink",
    }

    # Free tunneling / reverse-proxy services heavily abused by CamPhish,
    # phishing kits, RATs and credential-harvesting pages.
    # Legitimate organizations NEVER host public user-facing services on these.
    ABUSED_TUNNEL_SERVICES = {
        "trycloudflare.com",    # Cloudflare Tunnel (CamPhish, phishing kits)
        "ngrok.io",             # ngrok tunnels
        "ngrok-free.app",       # ngrok free tier
        "ngrok.app",
        "loca.lt",              # localtunnel
        "serveo.net",           # serveo reverse proxy
        "pagekite.me",          # pagekite
        "telebit.io",
        "localhost.run",
        "hookdns.com",
        "playit.gg",
        "boredparrot.xyz",
        "bore.pub",
        "portmap.io",
    }

    # Commonly abused high-risk generic/free TLDs
    SUSPICIOUS_TLDS = {
        "xyz",
        "top",
        "buzz",
        "fit",
        "tk",
        "ml",
        "ga",
        "cf",
        "gq",
        "work",
        "loan",
        "click",
        "rest",
        "country",
        "icu",
        "cam",
        "monster",
        "surf",
        "racing",
        "stream",
    }

    # High-profile brands frequently targeted by Indian and international phishers
    TARGET_BRANDS = [
        ("sbi", "State Bank of India"),
        ("hdfc", "HDFC Bank"),
        ("icici", "ICICI Bank"),
        ("axisbank", "Axis Bank"),
        ("paytm", "Paytm"),
        ("phonepe", "PhonePe"),
        ("gpay", "Google Pay"),
        ("google", "Google"),
        ("microsoft", "Microsoft"),
        ("apple", "Apple"),
        ("amazon", "Amazon"),
        ("flipkart", "Flipkart"),
        ("netflix", "Netflix"),
        ("paypal", "PayPal"),
        ("incometax", "Income Tax Department"),
        ("aadhaar", "Aadhaar / UIDAI"),
        ("uidai", "UIDAI"),
        ("indiapost", "India Post"),
        ("fedex", "FedEx"),
        ("bluedart", "Blue Dart"),
    ]

    # Phishing lures and action keywords
    SUSPICIOUS_KEYWORDS = [
        "login",
        "signin",
        "verify",
        "verification",
        "secure",
        "security",
        "update",
        "banking",
        "kyc",
        "pan-card",
        "account-blocked",
        "restore",
        "unlock",
        "wallet",
        "claim",
        "reward",
        "free-gift",
        "confirm",
        "authenticate",
        "billing",
    ]

    def analyze(self, raw_url: str) -> Dict[str, Any]:
        """
        Analyze a URL purely through offline string heuristics.
        Returns risk score, category, parsed components, indicators, and recommendations.
        """
        if not raw_url or not raw_url.strip():
            return {
                "score": 0,
                "category": "LOW",
                "category_class": "safe",
                "parsed": {},
                "positive_indicators": [],
                "risk_indicators": [],
                "explanation": "No URL entered for analysis.",
                "recommendations": [
                    "Paste a URL or select a sample link to evaluate its safety indicators."
                ],
                "is_valid": False,
                "raw_url": "",
            }

        url_str = raw_url.strip()
        if len(url_str) > self.MAX_URL_LENGTH:
            url_str = url_str[: self.MAX_URL_LENGTH]

        # Step 1: Reject hazardous non-HTTP schemes
        lower_url = url_str.lower()
        if lower_url.startswith(("javascript:", "data:", "file:", "vbscript:", "blob:")):
            scheme = lower_url.split(":", 1)[0]
            return {
                "score": 95,
                "category": "HIGH",
                "category_class": "danger",
                "parsed": {"scheme": scheme, "hostname": "", "path": "", "query": ""},
                "positive_indicators": [],
                "risk_indicators": [
                    {
                        "name": f"Dangerous Pseudo-Scheme ({scheme}:)",
                        "severity": "HIGH",
                        "weight": 95,
                        "description": (
                            f"The scheme '{scheme}:' is used in browser-side script execution, local file reading, "
                            "or XSS exploits rather than normal web navigation."
                        ),
                    }
                ],
                "explanation": (
                    f"CRITICAL RISK: '{scheme}:' is not a standard web protocol. Opening this can trigger malicious script "
                    "execution or exploit browser handling mechanisms."
                ),
                "recommendations": [
                    "DO NOT open or paste this link into your browser address bar.",
                    "Delete the message containing this link immediately.",
                ],
                "is_valid": False,
                "raw_url": url_str,
            }

        # Step 2: Normalize scheme for parsing
        has_scheme = bool(re.match(r"^[a-zA-Z][a-zA-Z0-9+\-.]*://", url_str))
        normalized_url = url_str if has_scheme else "http://" + url_str

        try:
            parsed = urlparse(normalized_url)
        except Exception:
            return {
                "score": 75,
                "category": "HIGH",
                "category_class": "danger",
                "parsed": {},
                "positive_indicators": [],
                "risk_indicators": [
                    {
                        "name": "Malformed URL Syntax",
                        "severity": "HIGH",
                        "weight": 75,
                        "description": "The URL cannot be parsed by standard RFC conforming URL parsers.",
                    }
                ],
                "explanation": "The submitted URL has corrupted or intentionally broken syntax.",
                "recommendations": ["Avoid interacting with malformed web addresses."],
                "is_valid": False,
                "raw_url": url_str,
            }

        scheme = (parsed.scheme or ("http" if not has_scheme else "")).lower()
        hostname = (parsed.hostname or "").lower()
        port = parsed.port
        path = parsed.path or "/"
        query = parsed.query or ""
        userinfo = parsed.username

        risk_indicators: List[Dict[str, Any]] = []
        positive_indicators: List[str] = []
        score = 0

        # Step 3: Check Scheme
        if not has_scheme:
            risk_indicators.append({
                "name": "Missing Protocol Scheme",
                "severity": "LOW",
                "weight": 10,
                "description": "URL was submitted without 'https://' or 'http://'. Browsers default to HTTP unless redirected.",
            })
            score += 10
        elif scheme == "https":
            positive_indicators.append(
                "Encrypted Transport (HTTPS): Data transmitted over this connection is encrypted in transit. (Note: HTTPS does not prove the website is honest)."
            )
        elif scheme == "http":
            risk_indicators.append({
                "name": "Unencrypted HTTP Scheme",
                "severity": "MEDIUM",
                "weight": 20,
                "description": "Uses unencrypted HTTP. Any passwords, cards, or personal data entered can be snooped or altered by local network eavesdroppers.",
            })
            score += 20
        else:
            risk_indicators.append({
                "name": f"Uncommon Scheme ({scheme})",
                "severity": "MEDIUM",
                "weight": 25,
                "description": f"Protocol scheme '{scheme}' is rarely used for legitimate consumer web browsing.",
            })
            score += 25

        # Step 4: Check User-Info Syntax (credential deception @ attack)
        # e.g., http://google.com@evil-site.com
        if "@" in (parsed.netloc or ""):
            risk_indicators.append({
                "name": "Deceptive User-Info Syntax (@ Symbol)",
                "severity": "HIGH",
                "weight": 40,
                "description": (
                    "The URL uses the user-info format 'user@host'. Attackers place trusted brand names before the '@' "
                    "to trick users, but the browser actually connects to the server AFTER the '@'."
                ),
            })
            score += 40

        # Step 5: Check Hostname & IP Address
        if not hostname:
            risk_indicators.append({
                "name": "Missing Hostname",
                "severity": "HIGH",
                "weight": 50,
                "description": "The URL has no destination host or domain name.",
            })
            score += 50
        else:
            # Check if hostname is an IP address
            is_ip = self._check_is_ip(hostname)
            if is_ip:
                risk_indicators.append({
                    "name": "Raw IP Address Hostname",
                    "severity": "HIGH",
                    "weight": 40,
                    "description": (
                        f"The host '{hostname}' is a raw numerical IP address instead of a registered domain. "
                        "Legitimate organizations almost never direct public users to raw IPs. Phishers use raw IPs to bypass domain registration controls."
                    ),
                })
                score += 40
            else:
                # Check hexadecimal or octal IP obfuscation
                if self._check_obfuscated_ip(hostname):
                    risk_indicators.append({
                        "name": "Obfuscated Integer/Hex IP Format",
                        "severity": "HIGH",
                        "weight": 45,
                        "description": "Uses numerical/hexadecimal IP encoding to evade URL filters.",
                    })
                    score += 45

            # Step 6: URL Shortener Check
            if hostname in self.SHORTENERS or any(hostname.endswith("." + s) for s in self.SHORTENERS):
                risk_indicators.append({
                    "name": "URL Shortener Service",
                    "severity": "MEDIUM",
                    "weight": 25,
                    "description": (
                        f"Host '{hostname}' is a known link-shortening service. Shortened links obscure the final destination, "
                        "preventing users and basic scanners from verifying where the link leads."
                    ),
                })
                score += 25

            # Step 6b: Free Tunnel / Reverse-Proxy Abuse Detection (CamPhish, Ngrok, Cloudflare Tunnel)
            matched_tunnel = next(
                (svc for svc in self.ABUSED_TUNNEL_SERVICES
                 if hostname == svc or hostname.endswith("." + svc)),
                None,
            )
            if matched_tunnel:
                risk_indicators.append({
                    "name": "Free Tunnel / Reverse-Proxy Service (High Abuse Risk)",
                    "severity": "HIGH",
                    "weight": 65,
                    "description": (
                        f"The host is served through '{matched_tunnel}', a free tunneling or reverse-proxy service. "
                        "Attackers and tools like CamPhish, phishing kits, and Remote-Access Trojans (RATs) routinely abuse "
                        "these platforms to host camera-phishing traps, credential-harvesting portals, and malware delivery pages "
                        "behind a trusted-looking HTTPS certificate. Legitimate organizations never direct public users to these services."
                    ),
                })
                score += 65

            # Step 7: Subdomain depth & length
            subdomain_parts = hostname.split(".")
            # e.g. login.verify.bank.sbi.evil.com
            if len(subdomain_parts) >= 4 and not is_ip:
                risk_indicators.append({
                    "name": "Excessive Subdomain Depth",
                    "severity": "MEDIUM",
                    "weight": 20,
                    "description": (
                        f"Host contains {len(subdomain_parts)} domain segments. Attackers create long subdomain chains to push the real domain "
                        "off-screen on mobile smartphone displays."
                    ),
                })
                score += 20

            # Step 8: Suspicious TLD check
            tld = subdomain_parts[-1] if len(subdomain_parts) > 1 else ""
            if tld in self.SUSPICIOUS_TLDS:
                risk_indicators.append({
                    "name": f"High-Risk Top-Level Domain (.{tld})",
                    "severity": "MEDIUM",
                    "weight": 20,
                    "description": (
                        f"The '.{tld}' extension is statistically associated with high volumes of disposable, low-cost spam and phishing registrations."
                    ),
                })
                score += 20

            # Step 9: Brand Spoofing / Typosquatting
            brand_findings = self._check_brand_spoofing(hostname, path, query)
            for brand_finding in brand_findings:
                risk_indicators.append(brand_finding)
                score += brand_finding["weight"]

            # Step 10: Suspicious keyword triggers
            keyword_findings = self._check_suspicious_keywords(hostname, path, query)
            for kw_finding in keyword_findings:
                risk_indicators.append(kw_finding)
                score += kw_finding["weight"]

        # Step 11: Length & Obfuscation
        if len(url_str) > 120:
            risk_indicators.append({
                "name": "Unusually Long URL",
                "severity": "LOW",
                "weight": 10,
                "description": f"URL length ({len(url_str)} chars) is excessively long, often used in tracking and token-smuggling.",
            })
            score += 10

        percent_encodings = len(re.findall(r"%[0-9a-fA-F]{2}", url_str))
        if percent_encodings > 6:
            risk_indicators.append({
                "name": "Heavy Percent-Encoding Obfuscation",
                "severity": "MEDIUM",
                "weight": 15,
                "description": f"URL contains {percent_encodings} percent-encoded tokens, which may hide the true path or parameters.",
            })
            score += 15

        # Check for non-standard port
        if port and port not in (80, 443):
            risk_indicators.append({
                "name": f"Non-Standard Web Port (:{port})",
                "severity": "MEDIUM",
                "weight": 15,
                "description": f"Traffic is directed to port {port} instead of standard web ports 80/443.",
            })
            score += 15

        # Positive indicator if clean
        if not risk_indicators:
            positive_indicators.append("Standard domain hierarchy and clean URL structure without known red flags.")
            positive_indicators.append("No user-info deception, raw IP addresses, or suspicious TLD patterns found.")

        # Final score calculation
        final_score = max(0, min(100, score))

        if final_score <= self.THRESHOLD_LOW_MAX:
            category = "LOW"
            category_class = "safe"
        elif final_score <= self.THRESHOLD_MEDIUM_MAX:
            category = "MEDIUM"
            category_class = "warning"
        else:
            category = "HIGH"
            category_class = "danger"

        explanation = self._build_explanation(category, final_score, risk_indicators, positive_indicators, hostname)
        recommendations = self._build_recommendations(category, risk_indicators)

        return {
            "score": final_score,
            "category": category,
            "category_class": category_class,
            "parsed": {
                "scheme": scheme or "none",
                "hostname": hostname or "none",
                "port": port or ("443" if scheme == "https" else "80"),
                "path": path,
                "query": query,
            },
            "positive_indicators": positive_indicators,
            "risk_indicators": risk_indicators,
            "explanation": explanation,
            "recommendations": recommendations,
            "is_valid": True,
            "raw_url": url_str,
        }

    def _check_is_ip(self, host: str) -> bool:
        """Check if hostname is a standard IPv4 or IPv6 literal."""
        # Strip brackets if IPv6
        clean_host = host.strip("[]")
        try:
            ipaddress.ip_address(clean_host)
            return True
        except ValueError:
            return False

    def _check_obfuscated_ip(self, host: str) -> bool:
        """Check if host is an integer or hex obfuscated IP."""
        # Decimal integer IP representation (e.g. 2130706433 = 127.0.0.1)
        if host.isdigit() and len(host) >= 7:
            return True
        # Hex representation (e.g. 0x7f000001)
        if host.startswith("0x") and len(host) >= 5:
            return True
        return False

    def _check_brand_spoofing(self, hostname: str, path: str, query: str) -> List[Dict[str, Any]]:
        """Identify instances of trusted brands appearing in deceptive contexts."""
        findings: List[Dict[str, Any]] = []
        host_parts = hostname.split(".")

        for brand_key, brand_name in self.TARGET_BRANDS:
            # Check if brand is in the hostname, but NOT the legitimate base domain
            # e.g., sbi-verification.xyz or login-hdfc.net
            if brand_key in hostname:
                # Is it the authentic official root domain?
                # For hackathon/heuristics, if host ends with official domain like google.com, amazon.in, etc.
                is_legit_root = any(
                    hostname == f"{brand_key}.com"
                    or hostname == f"{brand_key}.in"
                    or hostname == f"{brand_key}.co.in"
                    or hostname.endswith(f".{brand_key}.com")
                    or hostname.endswith(f".{brand_key}.in")
                    or hostname.endswith(f".{brand_key}.co.in")
                    for _ in [0]
                )

                if not is_legit_root:
                    findings.append({
                        "name": f"Brand Spoofing / Impersonation ({brand_name})",
                        "severity": "HIGH",
                        "weight": 35,
                        "description": (
                            f"The hostname mentions '{brand_name}' ({brand_key}), but appears to be hosted on an unaffiliated "
                            "third-party domain. This is the primary signature of brand impersonation phishing."
                        ),
                    })
                    break

            # Look-alike typosquatting checks (e.g., paytrm, amz0n, micros0ft, goog1e)
            typos = [
                (brand_key.replace("o", "0"), "0 for o"),
                (brand_key.replace("l", "1"), "1 for l"),
                (brand_key.replace("m", "rn"), "rn for m"),
            ]
            for typo_form, desc in typos:
                if typo_form != brand_key and typo_form in hostname:
                    findings.append({
                        "name": f"Look-alike Typosquatting ({brand_name})",
                        "severity": "HIGH",
                        "weight": 35,
                        "description": (
                            f"Domain contains '{typo_form}', a visual look-alike misspelling of '{brand_name}' ({desc})."
                        ),
                    })
                    break
        return findings

    def _check_suspicious_keywords(self, hostname: str, path: str, query: str) -> List[Dict[str, Any]]:
        """Detect phishing keyword lures in the URL path or hostname."""
        findings = []
        full_path_query = (path + "?" + query).lower()

        matched_kws = [kw for kw in self.SUSPICIOUS_KEYWORDS if kw in full_path_query or kw in hostname]
        if matched_kws:
            findings.append({
                "name": "Credential / Verification Lures in URL",
                "severity": "MEDIUM",
                "weight": 15,
                "description": (
                    f"URL contains sensitive action keywords: [{', '.join(matched_kws[:4])}]. "
                    "Scammers include these keywords to make fraudulent portals appear authentic."
                ),
            })
        return findings

    def _build_explanation(
        self,
        category: str,
        score: int,
        risk_indicators: List[Dict[str, Any]],
        positive_indicators: List[str],
        hostname: str,
    ) -> str:
        """Create human-readable summary of URL findings."""
        if category == "LOW":
            if not risk_indicators:
                return (
                    f"The URL for host '{hostname}' scored {score}/100 (LOW RISK). "
                    "Offline structural checks found standard formatting without suspicious IP usage, deceptive symbols, or brand spoofing."
                )
            return (
                f"The URL scored {score}/100 (LOW RISK). While a minor indicator was noted, the overall technical structure "
                "does not exhibit aggressive deception signatures."
            )

        if category == "MEDIUM":
            reasons = ", ".join([ind["name"] for ind in risk_indicators[:3]])
            return (
                f"EVALUATE CAREFULLY ({score}/100, MEDIUM RISK). This URL exhibits caution flags ({reasons}). "
                "Do not submit sensitive personal or financial information until you have verified the destination."
            )

        # HIGH
        reasons = ", ".join([ind["name"] for ind in risk_indicators[:3]])
        return (
            f"HIGH RISK DETECTED ({score}/100). The URL displays strong deception indicators, including {reasons}. "
            "These traits are heavily characteristic of phishing campaigns, credential harvesting, or malware delivery."
        )

    def _build_recommendations(
        self, category: str, risk_indicators: List[Dict[str, Any]]
    ) -> List[str]:
        """Generate targeted safety advice."""
        if category == "LOW":
            return [
                "Even with a low risk score, always confirm you intended to visit this specific domain.",
                "Verify that the address bar shows the expected domain before typing passwords.",
                "Remember: an HTTPS padlock confirms transport encryption, not that the website owner is benevolent.",
            ]

        recs = [
            "DO NOT click or open this link.",
            "NEVER enter login credentials, OTPs, or debit/credit card numbers on this website.",
        ]

        names = {ind["name"] for ind in risk_indicators}
        if "Raw IP Address Hostname" in names:
            recs.append("Legitimate institutions use named domains (e.g. yourbank.com), never raw IP addresses.")
        if any("Brand Spoofing" in n for n in names):
            recs.append("Navigate to the official service directly by typing its known official web address in your browser.")
        if "URL Shortener Service" in names:
            recs.append("If this short link came in an unsolicited message, treat the final destination as untrusted.")

        recs.append("Report suspicious links to the Indian Cyber Crime Reporting Portal at cybercrime.gov.in.")
        return recs


# Convenience singleton function
_analyzer_instance = URLAnalyzer()


def analyze_url(raw_url: str) -> Dict[str, Any]:
    """Analyze a URL with the default URLAnalyzer instance."""
    return _analyzer_instance.analyze(raw_url)
