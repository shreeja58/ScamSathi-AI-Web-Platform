"""
ScamSathi AI - Phishing & Scam Message Detector
Provides explainable, contextual, rule-based heuristics to analyze messages
for phishing, fraud, urgency extortion, credential theft, and prize scams.
"""

import html
import re
from typing import Any, Dict, List, Tuple


class MessageDetector:
    """Context-aware message analyzer with transparent risk scoring."""

    # Risk classification thresholds
    THRESHOLD_LOW_MAX = 29
    THRESHOLD_MEDIUM_MAX = 59

    # Max allowed input length (characters)
    MAX_INPUT_LENGTH = 5000

    def __init__(self) -> None:
        self._init_patterns()

    def _init_patterns(self) -> None:
        """Initialize compiled regular expressions for detection."""
        # Advisory / legitimate security education phrases
        self.advisory_patterns = [
            re.compile(
                r"\b(?:will\s+never\s+ask|never\s+share|do\s+not\s+share|don't\s+share|"
                r"never\s+disclose|beware\s+of\s+frauds?|scam\s+alert|security\s+tip|"
                r"official\s+helpline\s+only|never\s+send\s+your\s+otp)\b",
                re.IGNORECASE,
            ),
        ]

        # 1. High Urgency
        self.urgency_patterns = [
            (
                "Manufactured Urgency",
                re.compile(
                    r"\b(?:urgent(?:ly)?|immediate(?:ly)?|action\s+required|"
                    r"within\s+\d+\s+(?:hours?|hrs?|mins?|minutes?)|"
                    r"today\s+only|immediately\s+to\s+restore|restore\s+access|"
                    r"deadline\s+is\s+today|act\s+fast)\b",
                    re.IGNORECASE,
                ),
                15,
                "Creates panic to force the victim into acting before thinking critically.",
            ),
        ]

        # 2. Account Suspension & Blocking Threats
        self.suspension_patterns = [
            (
                "Account Suspension Threat",
                re.compile(
                    r"\b(?:account\s+will\s+be\s+(?:blocked|suspended|deactivated|closed|terminated|frozen)|"
                    r"card\s+will\s+be\s+blocked|services\s+will\s+be\s+(?:stopped|disconnected)|"
                    r"pan\s+(?:blocked|deactivated)|sim\s+card\s+will\s+be\s+(?:blocked|deactivated)|"
                    r"electricity\s+power\s+will\s+be\s+disconnected|bill\s+overdue\s+disconnect)\b",
                    re.IGNORECASE,
                ),
                25,
                "Uses fear of losing essential access or services to coerce compliance.",
            ),
        ]

        # 3. Lottery / Unexpected Prize / Reward
        self.prize_patterns = [
            (
                "Prize / Lottery / Reward Claim",
                re.compile(
                    r"\b(?:congratulations!?\s+you(?:'ve)?\s+(?:won|been\s+selected)|"
                    r"won\s+(?:a\s+)?(?:[\$₹€£]|rs\.?|inr)?\s*[\d,]+|"
                    r"lottery\s+winner|lucky\s+draw|cashback\s+reward\s+of|"
                    r"claim\s+(?:your\s+)?(?:prize|reward|gift\s+voucher|bonus))\b",
                    re.IGNORECASE,
                ),
                25,
                "Lures victims with fake financial rewards or sweepstake winnings.",
            ),
        ]

        # 4. Advance Fee / Processing Charges
        self.fee_patterns = [
            (
                "Advance Fee / Processing Charge Demand",
                re.compile(
                    r"\b(?:pay\s+(?:[\$₹€£]|rs\.?|inr)?\s*[\d,]+\s*(?:processing|registration|courier|delivery|clearance|service|verification)\s*(?:charges?|fees?|deposit)?|"
                    r"(?:processing|registration|clearance|refundable)\s*(?:charge|charges|fee|fees|deposit)\s*(?:of\s*)?(?:[\$₹€£]|rs\.?|inr)?\s*[\d,]+|"
                    r"pay\s+refundable\s+deposit|transfer\s+fee\s+to\s+claim)\b",
                    re.IGNORECASE,
                ),
                30,
                "Requires an upfront payment before releasing a nonexistent reward or job.",
            ),
        ]

        # 5. Credential & OTP Harvesting
        self.credential_patterns = [
            (
                "Credential / OTP Harvesting Request",
                re.compile(
                    r"\b(?:send|share|provide|enter|submit|reply\s+with|forward)\s+(?:your\s+)?"
                    r"(?:otp|one[- ]time\s+password|pin|password|cvv|m[- ]pin|"
                    r"login\s+credentials|passcode|secret\s+code)\b",
                    re.IGNORECASE,
                ),
                35,
                "Directly solicits sensitive authentication secrets that legitimate services never request.",
            ),
        ]

        # 6. Banking & Card Detail Requests
        self.banking_patterns = [
            (
                "Sensitive Financial Details Request",
                re.compile(
                    r"\b(?:enter|update|verify|submit|send)\s+(?:your\s+)?"
                    r"(?:bank\s+account\s+number|card\s+number|debit\s+card|credit\s+card|"
                    r"card\s+expiry|net\s*banking\s+password|upi\s+pin)\b",
                    re.IGNORECASE,
                ),
                25,
                "Asks for confidential banking details that could lead to unauthorized fund transfers.",
            ),
        ]

        # 7. Suspicious Links / Verification URLs
        self.link_patterns = [
            (
                "Suspicious Link / Verification Portal",
                re.compile(
                    r"https?://[^\s<>\"']+|www\.[^\s<>\"']+",
                    re.IGNORECASE,
                ),
                20,
                "Directs the user to an external link, often mimicking legitimate login portals.",
            ),
        ]

        # 8. Shortened URLs
        self.shortener_patterns = [
            (
                "Shortened URL Obfuscation",
                re.compile(
                    r"https?://(?:bit\.ly|tinyurl\.com|t\.co|is\.gd|rb\.gy|cutt\.ly|shorturl\.at|ow\.ly)/[^\s<>\"']+",
                    re.IGNORECASE,
                ),
                15,
                "Uses URL shorteners to conceal the actual website destination from the recipient.",
            ),
        ]

        # 9. Job / High Return Investment Scams
        self.job_patterns = [
            (
                "Unrealistic Job / Guaranteed Investment Offer",
                re.compile(
                    r"\b(?:earn\s+(?:[\$₹€£]|rs\.?|inr)?\s*[\d,]+\s*(?:daily|per\s+day|monthly|weekly)|"
                    r"work\s+from\s+home\s+(?:earn|part[- ]time)|part[- ]time\s+job\s+guaranteed|"
                    r"like\s+youtube\s+videos?\s+and\s+earn|telegram\s+task\s+job|"
                    r"guaranteed\s+(?:profit|returns?|income)|daily\s+payouts?\s+guaranteed)\b",
                    re.IGNORECASE,
                ),
                25,
                "Promises unrealistic income or guaranteed returns with zero risk or minimal effort.",
            ),
        ]

        # 10. Impersonation of Authority / Bank / Govt / Utilities
        self.impersonation_patterns = [
            (
                "Institutional Impersonation Clue",
                re.compile(
                    r"\b(?:sbi|state\s+bank\s+of\s+india|hdfc|icici|axis\s+bank|punjab\s+national\s+bank|"
                    r"rbi|reserve\s+bank\s+of\s+india|income\s+tax\s+department|customs\s+office|"
                    r"india\s+post|speed\s+post|fedex|bluedart|electricity\s+department|"
                    r"telecom\s+regulatory|kyc\s+team|aadhaar\s+verification|pan\s+department)\b",
                    re.IGNORECASE,
                ),
                10,
                "Mentions trusted public institutions, banks, or delivery couriers to build false credibility.",
            ),
        ]

    def analyze(self, message: str) -> Dict[str, Any]:
        """
        Analyze a text message and return a comprehensive, explainable risk assessment.
        """
        if not message or not message.strip():
            return {
                "score": 0,
                "category": "LOW",
                "category_class": "safe",
                "indicators": [],
                "highlights_html": "",
                "explanation": "No text provided for analysis.",
                "recommendations": [
                    "Paste a message from SMS, WhatsApp, or email to inspect it."
                ],
                "is_advisory": False,
                "original_message": "",
            }

        # Truncate to maximum input length safely
        cleaned_message = message.strip()
        if len(cleaned_message) > self.MAX_INPUT_LENGTH:
            cleaned_message = cleaned_message[: self.MAX_INPUT_LENGTH]

        # Step 1: Detect security advisory context (false positive mitigation)
        is_advisory = self._check_advisory_context(cleaned_message)

        # Step 2: Extract all indicators
        indicators: List[Dict[str, Any]] = []
        matched_spans: List[Tuple[int, int, str]] = []
        raw_score = 0

        # Check all rule sets
        rule_groups = [
            self.urgency_patterns,
            self.suspension_patterns,
            self.prize_patterns,
            self.fee_patterns,
            self.credential_patterns,
            self.banking_patterns,
            self.shortener_patterns,
            self.link_patterns,
            self.job_patterns,
            self.impersonation_patterns,
        ]

        detected_names = set()

        for group in rule_groups:
            for name, pattern, weight, explanation in group:
                matches = list(pattern.finditer(cleaned_message))
                if matches:
                    # In advisory context, suppress credential & impersonation weights
                    effective_weight = weight
                    if is_advisory and name in (
                        "Credential / OTP Harvesting Request",
                        "Sensitive Financial Details Request",
                        "Institutional Impersonation Clue",
                    ):
                        continue

                    # Don't duplicate generic link indicator if shortener is already detected
                    if name == "Suspicious Link / Verification Portal" and "Shortened URL Obfuscation" in detected_names:
                        effective_weight = 5

                    matched_texts = [m.group(0) for m in matches]
                    for m in matches:
                        matched_spans.append((m.start(), m.end(), name))

                    if name not in detected_names:
                        detected_names.add(name)
                        raw_score += effective_weight
                        indicators.append({
                            "name": name,
                            "severity": self._severity_label(effective_weight),
                            "weight": effective_weight,
                            "description": explanation,
                            "matched_phrases": list(dict.fromkeys(matched_texts))[:3],
                        })

        # Step 3: Composite risk boosters (synergistic risk patterns)
        composite_bonuses = []
        if (
            "Account Suspension Threat" in detected_names
            and ("Suspicious Link / Verification Portal" in detected_names or "Credential / OTP Harvesting Request" in detected_names)
        ):
            raw_score += 15
            composite_bonuses.append("Urgent Threat + Verification Trap combo detected")

        if (
            "Prize / Lottery / Reward Claim" in detected_names
            and "Advance Fee / Processing Charge Demand" in detected_names
        ):
            raw_score += 20
            composite_bonuses.append("Prize Scam + Upfront Fee extortion combo detected")

        # Step 4: Handle advisory override
        if is_advisory and raw_score > 0:
            # Dampen score to safe zone if it's purely security awareness
            raw_score = min(raw_score, 15)

        # Cap score between 0 and 100
        final_score = max(0, min(100, raw_score))

        # Categorize
        if final_score <= self.THRESHOLD_LOW_MAX:
            category = "LOW"
            category_class = "safe"
        elif final_score <= self.THRESHOLD_MEDIUM_MAX:
            category = "MEDIUM"
            category_class = "warning"
        else:
            category = "HIGH"
            category_class = "danger"

        # Generate safely escaped highlighted HTML
        highlights_html = self._generate_safe_highlights(cleaned_message, matched_spans)

        # Generate plain-language explanation & tailored recommendations
        explanation = self._build_explanation(
            category, final_score, indicators, is_advisory, composite_bonuses
        )
        recommendations = self._build_recommendations(category, indicators, is_advisory)

        return {
            "score": final_score,
            "category": category,
            "category_class": category_class,
            "indicators": indicators,
            "highlights_html": highlights_html,
            "explanation": explanation,
            "recommendations": recommendations,
            "is_advisory": is_advisory,
            "original_message": cleaned_message,
        }

    def _check_advisory_context(self, text: str) -> bool:
        """Detect whether the message is a legitimate bank security warning or advisory."""
        for pattern in self.advisory_patterns:
            if pattern.search(text):
                # Also check if it doesn't contain a phishing URL asking for action
                # Legitimate advisories rarely tell you to click a third-party link to restore access
                has_threat_action = bool(
                    re.search(r"click\s+here|restore\s+access|verify\s+immediately", text, re.IGNORECASE)
                )
                if not has_threat_action:
                    return True
        return False

    def _severity_label(self, weight: int) -> str:
        if weight >= 25:
            return "HIGH"
        if weight >= 15:
            return "MEDIUM"
        return "LOW"

    def _generate_safe_highlights(
        self, text: str, spans: List[Tuple[int, int, str]]
    ) -> str:
        """
        Produce HTML with suspicious words highlighted.
        Strictly escapes all non-markup text to prevent XSS.
        """
        if not spans:
            return html.escape(text)

        # Sort spans by start offset, eliminate overlaps
        spans = sorted(spans, key=lambda x: (x[0], -x[1]))
        merged_spans: List[Tuple[int, int, str]] = []

        last_end = -1
        for start, end, label in spans:
            if start >= last_end:
                merged_spans.append((start, end, label))
                last_end = end

        # Build output string
        output_chunks = []
        current_idx = 0

        for start, end, label in merged_spans:
            # Non-highlighted preceding text (escaped)
            if start > current_idx:
                output_chunks.append(html.escape(text[current_idx:start]))
            # Highlighted snippet
            highlighted_snippet = html.escape(text[start:end])
            label_attr = html.escape(label)
            output_chunks.append(
                f'<mark class="phish-highlight" title="{label_attr}">{highlighted_snippet}</mark>'
            )
            current_idx = end

        if current_idx < len(text):
            output_chunks.append(html.escape(text[current_idx:]))

        return "".join(output_chunks)

    def _build_explanation(
        self,
        category: str,
        score: int,
        indicators: List[Dict[str, Any]],
        is_advisory: bool,
        composite_bonuses: List[str],
    ) -> str:
        """Synthesize findings into an explainable paragraph."""
        if is_advisory:
            return (
                "This message was identified as a legitimate security advisory or public awareness notice. "
                "It reminds users to protect sensitive credentials such as OTPs and PINs rather than attempting to harvest them."
            )

        if category == "LOW":
            if not indicators:
                return (
                    "No common phishing, urgency, or credential-harvesting indicators were detected. "
                    "The message appears consistent with routine communication."
                )
            return (
                f"The message received a low heuristic risk score of {score}/100. "
                "A few minor contextual keywords were found, but no aggressive coercion or credential-theft patterns were identified."
            )

        if category == "MEDIUM":
            detected_summary = ", ".join([ind["name"] for ind in indicators[:3]])
            return (
                f"Caution advised. This message scored {score}/100 due to warning indicators ({detected_summary}). "
                "While not definitively fraudulent, it contains psychological or technical pressure tactics commonly observed in scam campaigns."
            )

        # HIGH risk
        detected_summary = ", ".join([ind["name"] for ind in indicators[:4]])
        bonus_text = f" Additionally, {', '.join(composite_bonuses)}." if composite_bonuses else ""
        return (
            f"HIGH RISK DETECTED ({score}/100). This message exhibits multiple classic scam indicators, including {detected_summary}.{bonus_text} "
            "Scammers use these combined tactics to induce panic and trick recipients into relinquishing funds or account control."
        )

    def _build_recommendations(
        self, category: str, indicators: List[Dict[str, Any]], is_advisory: bool
    ) -> List[str]:
        """Provide concrete, actionable safety tips."""
        if is_advisory:
            return [
                "Remember the advice: legitimate banks never ask for your full OTP or password.",
                "Keep the official customer support number saved on your phone for verification.",
            ]

        if category == "LOW":
            return [
                "Always verify the sender's identity through official channels if sensitive data is requested later.",
                "Avoid sharing OTPs, passwords, or personal identity numbers even in seemingly routine conversations.",
                "Ensure your communication apps have spam filters and two-factor authentication enabled.",
            ]

        # Medium / High risk actions
        recs = [
            "DO NOT click any links or download attachments found in this message.",
            "NEVER share OTPs, PINs, or banking passwords with anyone under any circumstances.",
        ]

        indicator_names = {ind["name"] for ind in indicators}

        if "Advance Fee / Processing Charge Demand" in indicator_names:
            recs.append("Refuse any demand for 'processing charges' or 'advance deposits' to receive a prize or job.")
        if "Account Suspension Threat" in indicator_names:
            recs.append("Contact your bank directly via the phone number printed on the back of your card, not via numbers in the message.")
        if "Suspicious Link / Verification Portal" in indicator_names or "Shortened URL Obfuscation" in indicator_names:
            recs.append("Inspect links using our URL Analyzer before considering opening any web destination.")

        recs.append("Report fraudulent SMS/WhatsApp messages to India's National Cyber Crime Portal (cybercrime.gov.in) or call 1930.")
        return recs


# Convenience singleton function
_detector_instance = MessageDetector()


def analyze_message(message: str) -> Dict[str, Any]:
    """Analyze a message with the default MessageDetector instance."""
    return _detector_instance.analyze(message)
